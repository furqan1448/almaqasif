/**
 * نظام وحدة المقاصف - جمعية فرقان لتحفيظ القرآن الكريم
 * الكود الخلفي (Google Apps Script)
 *
 * طريقة التركيب:
 * 1) افتحي Google Sheet جديد فاضي (أو استخدمي شيتك الحالي).
 * 2) من القائمة: Extensions > Apps Script
 * 3) احذفي أي كود موجود، والصقي هذا الكود كامل.
 * 4) عدّلي القيمة ADMIN_NOTIFY_EMAIL أدناه ببريدك الإلكتروني.
 * 5) شغلي دالة setup() مرة وحدة من القائمة أعلى المحرر (لإنشاء الشيتات والأعمدة الناقصة تلقائياً).
 * 6) Deploy > Manage deployments > ✏️ تعديل > New version > Deploy
 *    (أو New deployment لو أول مرة، وبعدها حطي الرابط بملف config.js)
 */

const FOLDER_NAME = 'مرفقات نظام المقاصف';

// ⚠️ حطي بريدك الإلكتروني هنا عشان تستلمي إشعار كل ما مركز يرسل إشعار استلام أو تسليم
const ADMIN_NOTIFY_EMAIL = 'fainal.almqasif@gmail.com';

// الأعمدة اللي المفروض دايماً تُحفظ وتُقرأ كنص خام (وليست تاريخ/وقت تلقائي من قوقل شيتس)
// عشان نتفادى مشكلة "الأصفار الزايدة" (مثل 1899-12-30 أو 00:00:00.000Z) اللي تصير
// لما قوقل شيتس يحوّل نص التاريخ/الوقت تلقائياً إلى كائن Date داخلي.
const TEXT_COLUMNS_ = ['اليوم', 'التاريخ', 'الوقت', 'تاريخ الإرسال', 'يوم الإرسال', 'وقت الإرسال',
  'يوم اطلاع الإدارة', 'تاريخ اطلاع الإدارة', 'وقت اطلاع الإدارة', 'تاريخ توقيع الإدارة',
  'رقم الفاتورة', 'العام', 'وقت التسجيل الفعلي', 'يوم الاجتماع', 'تاريخ الاجتماع الهجري', 'رقم الاجتماع'];

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  const sheets = {
    'المسؤولات': ['الاسم', 'البريد الإلكتروني', 'كلمة المرور', 'اسم المركز'],
    'الحضور': ['الاسم', 'اليوم', 'التاريخ', 'الوقت'],
    'التعهد': ['الاسم', 'نص التعهد', 'اليوم', 'التاريخ', 'الوقت', 'الحالة'],
    'المهام': ['الاسم', 'البريد الإلكتروني', 'نص المهام', 'اليوم', 'التاريخ', 'الوقت', 'الحالة'],
    'المراكز': ['اسم المركز', 'كلمة المرور', 'وضع العرض فقط', 'الاسم المعروض'],
    'المبيعات': ['معرف', 'اسم المركز', 'اليوم', 'التاريخ', 'الوقت', 'المبلغ', 'ملاحظات', 'الفصل الدراسي', 'وقت التسجيل الفعلي'],
    'المرتجعات': ['معرف', 'اسم المركز', 'اليوم', 'التاريخ', 'وصف الصنف', 'الكمية', 'القيمة', 'ملاحظات', 'الفصل الدراسي'],
    'الفواتير': ['معرف', 'اسم المركز', 'رقم الفاتورة', 'مصدر الفاتورة', 'اليوم', 'التاريخ', 'المبلغ الإجمالي', 'الربح', 'ملاحظات', 'الفصل الدراسي'],
    'الإشعارات': ['معرف', 'النوع', 'اسم المركز', 'يوم الإرسال', 'تاريخ الإرسال', 'وقت الإرسال',
      'اسم المسلّمة', 'المبلغ', 'الشهر', 'الفصل الدراسي', 'العام', 'بيان مخصص',
      'رابط توقيع المركز', 'رابط صورة الإشعار', 'الحالة',
      'رابط توقيع الإدارة', 'رابط صورة الإشعار الموقع',
      'يوم اطلاع الإدارة', 'تاريخ اطلاع الإدارة', 'وقت اطلاع الإدارة',
      'اسم المستلمة', 'بيانات توقيع المركز', 'فصل الأرشفة'],
    'المرفقات': ['معرف', 'العنوان', 'النوع', 'الرابط', 'اسم الملف', 'من', 'المالك', 'اليوم', 'التاريخ', 'الوقت'],
    'مرفقات الإشراف': ['معرف', 'العنوان', 'النوع', 'الرابط', 'اسم الملف', 'من', 'اليوم', 'التاريخ', 'الوقت'],
    'الإعلانات الهامة': ['معرف', 'النص', 'استهداف', 'من', 'اليوم', 'التاريخ', 'الوقت'],
    // محاضر الاجتماعات: كل الحقول التي تُطبع بالمحضر + استهداف (زي الإعلانات الهامة) يحدد مين يشوفه بالمراكز/المسؤولات
    'محاضر الاجتماعات': ['معرف', 'رقم الاجتماع', 'يوم الاجتماع', 'تاريخ الاجتماع الهجري', 'طريقة الانعقاد',
      'نقاط الاجتماع', 'المشاركات', 'الروابط',
      'اسم الرئيسة', 'توقيع الرئيسة', 'حجم توقيع الرئيسة',
      'اسم المساعدة', 'توقيع المساعدة', 'حجم توقيع المساعدة',
      'استهداف', 'من', 'اليوم', 'التاريخ', 'الوقت'],
    'قائمة الأسعار': ['معرف', 'التصنيف', 'اسم الصنف', 'السعر', 'ترتيب'],
    'الإعدادات': ['المفتاح', 'القيمة'],
    'دخول الإشراف': ['البريد الإلكتروني', 'كلمة المرور', 'الاسم'],
    'الصعوبات والمقترحات': ['معرف', 'اسم المركز', 'من', 'النوع', 'النص', 'اليوم', 'التاريخ', 'الوقت'],
    'قائمة الدخل': ['معرف', 'البند', 'البيان', 'المبلغ', 'المبلغ كتابة', 'اليوم', 'التاريخ', 'الفصل الدراسي', 'رابط المرفق', 'اسم المرفق'],
    // بطاقات التحفيز: سجلّين منفصلين بنفس الشيت (نوع السجل: تسليم / استلام)، كل سطر بطاقة موقّعة
    // (رسم أو صورة) من الشخص المستلم وقتها. بدون أرشفة تلقائية عشان الحقوق تفضل واضحة
    'بطاقات التحفيز': ['معرف', 'اسم المركز', 'الدور', 'نوع السجل', 'نوع البطاقة', 'القيمة', 'الكمية',
      'اسم المستلمة', 'التوقيع', 'اليوم', 'التاريخ', 'الوقت'],
    // متابعة بطاقات التحفيز: توزيع الكمية الواحدة (من سطر "تسليم") على أكثر من مستفيدة -
    // كل سطر هنا = جزء من الكمية الأصلية باسم مستفيدة معيّنة وحالتها، ومجموعها ما يتجاوز
    // الكمية المسجّلة بسطر التسليم الأصلي (يُتحقق منه بـ addIncentiveFollowupSplit_)
    'متابعة بطاقات التحفيز': ['معرف', 'معرف السطر الأصلي', 'اسم المركز', 'اسم المستفيدة', 'العدد',
      'الحالة', 'اليوم', 'التاريخ'],
    // درجات المسؤولات: تقييم نهاية الفصل من 13 (يدوي من لوحة الإدارة) - صف لكل (فصل + مسؤولة)
    'درجات المسؤولات': GRADES_HEADERS_
  };

  Object.keys(sheets).forEach(function (name) {
    let sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    if (sh.getLastRow() === 0) {
      sh.appendRow(sheets[name]);
      sh.getRange(1, 1, 1, sheets[name].length).setFontWeight('bold');
      sh.setRightToLeft(true);
    } else {
      // إذا كان الشيت موجود من قبل بأعمدة أقل (تحديث نظام قديم)، نضيف الأعمدة الناقصة بآخر الصف.
      // نتجاهل المسافات الزائدة بالمقارنة (نفس سبب مشكلة "اليوم ما ينكتب") حتى ما ينضاف
      // عمود مكرر لو كان الموجود مسبقاً فيه مسافة خفية بالاسم.
      const existingHeaders = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function (h) { return String(h).trim(); });
      sheets[name].forEach(function (col) {
        if (existingHeaders.indexOf(col) === -1) {
          sh.getRange(1, sh.getLastColumn() + 1).setValue(col).setFontWeight('bold');
          existingHeaders.push(col); // نحدّث القائمة بالذاكرة عشان ما نضيف نفس العمود مرتين بهذي التشغيلة
        }
      });
    }

    // نجبر أعمدة التاريخ/الوقت على تنسيق "نص عادي" حتى لا يحوّلها قوقل شيتس
    // تلقائياً إلى كائن Date (وهذا هو مصدر "الأصفار الزايدة")
    const headersNow = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
    headersNow.forEach(function (h, idx) {
      if (TEXT_COLUMNS_.indexOf(h) !== -1) {
        sh.getRange(2, idx + 1, Math.max(sh.getMaxRows() - 1, 1), 1).setNumberFormat('@');
      }
    });
  });

  // شيت مثال - عدليه بأسماء المراكز الحقيقية وكلمات المرور
  const centersSheet = ss.getSheetByName('المراكز');
  if (centersSheet.getLastRow() === 1) {
    centersSheet.appendRow(['مركز تحفيظ 1', '1234']);
    centersSheet.appendRow(['مركز تحفيظ 2', '5678']);
  }

  // تعبئة قائمة الأسعار بالأصناف الأولية (مرة وحدة بس - لو الشيت لسا فاضي)
  const priceSheet = ss.getSheetByName('قائمة الأسعار');
  if (priceSheet.getLastRow() === 1) {
    seedPriceList_(priceSheet);
  }

  notify_('تم إنشاء/تحديث جميع الشيتات بنجاح. تأكدي من تعبئة عمود "اسم المركز" بشيت "المسؤولات" لكل مسؤولة، وتحطي بريدك في ADMIN_NOTIFY_EMAIL أعلى الكود.\n\nملاحظة: لو كان عندك شيت قديم وفيه بيانات، شغّلي أيضاً دالة fixOldDateColumns من قائمة الدوال فوق المحرر مرة وحدة عشان تصلح صيغة الأعمدة القديمة، ودالة fillMissingDayNames لو لاحظتِ إن عمود "اليوم" فاضي بصفوف قديمة بالمبيعات/المرتجعات/الفواتير.');
}

/* تعبئة أولية لقائمة الأسعار من قائمة المقصف الورقية - تتنفذ تلقائياً من setup() مرة وحدة بس
   (لو الشيت فاضي). بعدها التعديل/الإضافة/الحذف من لوحة الإدارة (أو المسؤولة المخوّلة) مباشرة. */
function seedPriceList_(sh) {
  const items = [
    ['البطاطسات', 'فخذ الدجاج', '1'], ['البطاطسات', 'فانتزي', '1'], ['البطاطسات', 'حروف صغيرة', '1'],
    ['البطاطسات', 'ليز', '1'], ['البطاطسات', 'تسالي صغير', '1'], ['البطاطسات', 'البطل دبي', '1'],
    ['البطاطسات', 'مرامي صغير', '1'], ['البطاطسات', 'البطل فشار صغير', '1'], ['البطاطسات', 'فرفشة عيدان', '1'],
    ['البطاطسات', 'لولز', '1'], ['البطاطسات', 'زورو', '1'], ['البطاطسات', 'زيكو', '1'],
    ['البطاطسات', 'راجا', '1'], ['البطاطسات', 'زمزم طماطم', 'حبتين بريال'], ['البطاطسات', 'عيدان ستيكس علب', '3'],
    ['البطاطسات', 'ستيكس اكياس', '1'], ['البطاطسات', 'عيدان الذرة مليونير', '1'], ['البطاطسات', 'دوريتوس', '2'],
    ['البطاطسات', 'بطاطس عمان', '1.5'],

    ['الحلويات', 'حلاوة قلب', 'حبتين بريال'], ['الحلويات', 'مصاص ديما', 'حبتين بريال'],
    ['الحلويات', 'فروتي ديما', '1'], ['الحلويات', 'ملعقة سينو', '1'], ['الحلويات', 'بهلول', '1'],

    ['الماء والعصيرات', 'مياه العين', '1'], ['الماء والعصيرات', 'مياه فو', '1'],
    ['الماء والعصيرات', 'عصير أورجينال صغير', '1'], ['الماء والعصيرات', 'عصير نكتار أورجينال كبير', '1.5'],
    ['الماء والعصيرات', 'حليب مراعي', '1.5'], ['الماء والعصيرات', 'حليب نادك', '1.5'],
    ['الماء والعصيرات', 'كأس شاي', '1'], ['الماء والعصيرات', 'كأس حليب', '2'],
    ['الماء والعصيرات', 'نسكافيه', '3'], ['الماء والعصيرات', 'أربعة أكواب فارغة', '1'],
    ['الماء والعصيرات', 'قهوة سوداء', '5'],

    ['الكيك والكروسون', 'فطاير', '1.5'], ['الكيك والكروسون', 'كرواسون سفن دايز', '2'],
    ['الكيك والكروسون', 'كيك يمامة', '1'], ['الكيك والكروسون', 'كيك نحول', '1'],
    ['الكيك والكروسون', 'كيك مفن', '1'], ['الكيك والكروسون', 'كيك سراي', '1'],

    ['البساكيت', 'لواكر', '2'], ['البساكيت', 'سندوتش ميرو بالمارشملو', '1'],
    ['البساكيت', 'ساندوتش اولكر صغير', '1'], ['البساكيت', 'بريك صغير اصبعين', '1'],
    ['البساكيت', 'ويفر تايم كريب', '1'], ['البساكيت', 'ويف هيرو ستار بندق', '1'],
    ['البساكيت', 'سبلاش بيكادلي', '1'], ['البساكيت', 'امادا شكولوف', '1'],
    ['البساكيت', 'فول سوداني', '1'], ['البساكيت', 'وافل غندور', '1'],
    ['البساكيت', 'بسكوت بريك', '1'], ['البساكيت', 'بسكوت اوه بوي', '1'],
    ['البساكيت', 'واو بافل', '1'], ['البساكيت', 'بسكوت فايف مش', '1'],
    ['البساكيت', 'سويش كوكيز', '1'], ['البساكيت', 'ويفر مثلثات', '1'],

    ['الشوكولاتات', 'فليك', '2'], ['الشوكولاتات', 'تويكس أصبعين', '3'], ['الشوكولاتات', 'توكس أصبع', '2'],
    ['الشوكولاتات', 'سنيكرس كبير', '3'], ['الشوكولاتات', 'سنيكرس صغير', '2'],
    ['الشوكولاتات', 'جالكسي سادة كبير', '3'], ['الشوكولاتات', 'جالكسي فلوتات', '2'],
    ['الشوكولاتات', 'جالكسي كرسبي صغير', '2'], ['الشوكولاتات', 'جالكسي كراميل صغير', '2'],
    ['الشوكولاتات', 'مارس صغير', '2'], ['الشوكولاتات', 'كيندربوينو', '3'],
    ['الشوكولاتات', 'باونتي كبير', '3'], ['الشوكولاتات', 'كيكت كات شنكي', '3'],
    ['الشوكولاتات', 'كيت كات صغير', '1.5'], ['الشوكولاتات', 'كاراميلا صغير', '2'],
    ['الشوكولاتات', 'شوكولاتة بالو 3 أصابع', '1'], ['الشوكولاتات', 'تريكسي', '1'],
    ['الشوكولاتات', 'شوكولاتة غونتس', '1']
  ];
  const rows = items.map(function (it, idx) {
    return [Utilities.getUuid(), it[0], it[1], it[2], idx + 1];
  });
  sh.getRange(2, 1, rows.length, 5).setValues(rows);
}

/* تشغّل مرة وحدة (اختياري) لو عندك شيتات قديمة فيها بيانات تاريخ/وقت محفوظة
   كـ Date تلقائي من قوقل شيتس، عشان تحوّلها لنص واضح بدون أصفار زايدة. */
function fixOldDateColumns() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  ['المبيعات', 'المرتجعات', 'الفواتير', 'الحضور', 'التعهد', 'المهام', 'الإشعارات'].forEach(function (name) {
    const sh = ss.getSheetByName(name);
    if (!sh || sh.getLastRow() < 2) return;
    const lastCol = sh.getLastColumn();
    const headers = sh.getRange(1, 1, 1, lastCol).getValues()[0];
    const range = sh.getRange(2, 1, sh.getLastRow() - 1, lastCol);
    const values = range.getValues();
    headers.forEach(function (h, idx) {
      if (TEXT_COLUMNS_.indexOf(h) === -1) return;
      const isTimeCol = (h === 'الوقت' || h === 'وقت الإرسال' || h === 'وقت اطلاع الإدارة');
      for (let i = 0; i < values.length; i++) {
        const v = values[i][idx];
        if (v instanceof Date) {
          values[i][idx] = isTimeCol
            ? Utilities.formatDate(v, Session.getScriptTimeZone(), 'HH:mm')
            : Utilities.formatDate(v, Session.getScriptTimeZone(), 'yyyy-MM-dd');
        }
      }
    });
    sh.getRange(1, 1, 1, lastCol).setNumberFormat('@'); // احتياط
    range.setNumberFormat('@');
    range.setValues(values);
  });
  invalidateCache_('المبيعات'); invalidateCache_('المرتجعات'); invalidateCache_('الفواتير');
  invalidateCache_('الحضور'); invalidateCache_('التعهد'); invalidateCache_('الإشعارات');
  notify_('تم تحويل أعمدة التاريخ والوقت القديمة إلى نص واضح بدون أصفار زايدة.');
}

/* أسماء أيام الأسبوع بالعربي - الأحد أول الأسبوع */
const AR_DAYS_ = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

/* بديل آمن لـ SpreadsheetApp.getUi().alert() - يشتغل سواء نفّذتِ الدالة من زر
   "تشغيل" بمحرر Apps Script مباشرة (ما فيه واجهة شيت متاحة وقتها) أو من قائمة
   مخصصة داخل الشيت نفسه. لو ما قدر يفتح نافذة تنبيه، يسجّل الرسالة بسجل التنفيذ
   (Logger) عشان تقدري تشوفينها من "عرض" ← "سجلات التنفيذ" (Execution log). */
function notify_(message) {
  try {
    SpreadsheetApp.getUi().alert(message);
  } catch (e) {
    Logger.log(message);
  }
}

function dayName_(d) {
  return AR_DAYS_[d.getDay()];
}

/* ترجع اليوم/التاريخ/الوقت الحالي كنص واضح بدون أي أصفار زايدة */
function nowParts_() {
  const tz = Session.getScriptTimeZone();
  const now = new Date();
  return {
    day: dayName_(now),
    date: Utilities.formatDate(now, tz, 'yyyy-MM-dd'),
    time: Utilities.formatDate(now, tz, 'HH:mm')
  };
}

/* ترجع اسم اليوم بالعربي لتاريخ نصي بصيغة yyyy-MM-dd (تُستخدم لو المستخدمة
   عدّلت التاريخ يدوياً في الواجهة عشان يبقى اسم اليوم مطابق للتاريخ المختار) */
function dayNameForDateStr_(dateStr) {
  if (!dateStr) return dayName_(new Date());
  const parts = String(dateStr).split('-');
  if (parts.length !== 3) return dayName_(new Date());
  const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  return dayName_(d);
}

function getOrCreateFolder_() {
  const folders = DriveApp.getFoldersByName(FOLDER_NAME);
  if (folders.hasNext()) return folders.next();
  return DriveApp.createFolder(FOLDER_NAME);
}

/* ينظّف اسم مجلد/ملف من الرموز الممنوعة بـ Drive */
function safeName_(s) {
  return String(s || '').replace(/[\\\/:*?"<>|]/g, ' ').replace(/\s+/g, ' ').trim() || 'بدون اسم';
}

/* يرجّع مجلد فرعي داخل المجلد الرئيسي حسب المسار (مثلاً ['الإشعارات', 'اسم المركز']) وينشئه لو مو موجود.
   نخزّن معرّف كل مجلد بالكاش عشان ما نبحث بـ Drive كل مرة (أسرع بالحفظ). */
function getOrCreateSubFolder_(pathArr) {
  const cache = CacheService.getScriptCache();
  let parent = getOrCreateFolder_();
  let key = 'fld';
  for (let i = 0; i < pathArr.length; i++) {
    const name = safeName_(pathArr[i]);
    key += '/' + name;
    const ck = key.length > 240 ? key.slice(0, 240) : key;
    let folder = null;
    const cachedId = cache.get(ck);
    if (cachedId) {
      try { folder = DriveApp.getFolderById(cachedId); } catch (e) { folder = null; }
    }
    if (!folder) {
      const it = parent.getFoldersByName(name);
      folder = it.hasNext() ? it.next() : parent.createFolder(name);
      cache.put(ck, folder.getId(), 21600);
    }
    parent = folder;
  }
  return parent;
}

/* subPath (اختياري): مسار المجلد الفرعي، مثلاً ['الإشعارات', 'اسم المركز'].
   لو ما انمرّر تنحفظ الصورة بالمجلد الرئيسي مثل قبل. */
function saveImage_(base64Data, fileName, subPath) {
  if (!base64Data) return '';
  const cleaned = base64Data.replace(/^data:image\/\w+;base64,/, '');
  const bytes = Utilities.base64Decode(cleaned);
  const blob = Utilities.newBlob(bytes, 'image/png', safeName_(fileName) + '.png');
  const folder = (subPath && subPath.length) ? getOrCreateSubFolder_(subPath) : getOrCreateFolder_();
  const file = folder.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  // file.getUrl() ترجع رابط صفحة عرض بقوقل درايف، وما تشتغل مباشرة داخل <img src>.
  // هذا الرابط هو الصيغة الصحيحة لعرض الصورة مباشرة بالمتصفح (وبتاق <img>)
  return 'https://lh3.googleusercontent.com/d/' + file.getId();
}

/* اسم ملف واضح للإشعار: النوع - المركز - التاريخ - جزء من المعرف */
function noticeFileName_(prefix, type, center, date, id) {
  return [prefix, type, center, date, String(id || '').slice(0, 6)]
    .filter(function (x) { return String(x || '').trim(); }).join(' - ');
}

/* نفس فكرة saveImage_ بس لأي نوع ملف (PDF، Word، صورة...) مو بس PNG -
   تُستخدم لرفع مرفقات المستخدمات (خانة "إضافة مرفقات"). ترجع رابط عرض/تحميل
   عادي بقوقل درايف (يشتغل بفتح تبويب جديد، عكس رابط saveImage_ المخصص للعرض داخل <img>) */
function saveAttachmentFile_(base64Data, fileName, mimeType) {
  if (!base64Data) return '';
  const cleaned = String(base64Data).replace(/^data:[^;]+;base64,/, '');
  const bytes = Utilities.base64Decode(cleaned);
  const blob = Utilities.newBlob(bytes, mimeType || 'application/octet-stream', fileName || 'مرفق');
  const root = getOrCreateFolder_();
  const folders = root.getFoldersByName('المرفقات');
  const folder = folders.hasNext() ? folders.next() : root.createFolder('المرفقات');
  const file = folder.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return file.getUrl();
}

/* تسجّل مرفق جديد (ملف أو رابط). p.store: اسم الشيت الوجهة - افتراضياً 'المرفقات'
   (المشتركة بين المراكز/المسؤولات/الإدارة)، أو 'مرفقات الإشراف' لمكتب إشراف الداخل.
   p.kind: 'file' أو 'link'. لو 'file' لازم p.fileData (base64) و p.fileName و p.mimeType.
   لو 'link' لازم p.link. p.from: اسم الجهة المضيفة (مركز/مسؤولة/الإدارة) للعرض بس.
   p.owner: مُعرّف الجهة المالكة (اسم المركز عادةً، أو بريد المسؤولة لو ما لها مركز) -
   يُستخدم لإخفاء المرفق عن باقي المراكز/المسؤولات (كل جهة تشوف مرفقاتها هي بس، والإدارة تشوف الكل). */
function recordAttachment_(p) {
  const sh = sheet_(p.store || 'المرفقات');
  const id = Utilities.getUuid();
  const now = nowParts_();
  let link = '';
  let fileName = '';
  if (p.kind === 'file') {
    link = saveAttachmentFile_(p.fileData, p.fileName || (p.title || id), p.mimeType || '');
    fileName = p.fileName || '';
  } else {
    link = p.link || '';
  }
  appendRowByHeaders_(sh, {
    'معرف': id, 'العنوان': p.title || '', 'النوع': p.kind === 'file' ? 'ملف' : 'رابط',
    'الرابط': link, 'اسم الملف': fileName, 'من': p.from || '', 'المالك': p.owner || '',
    'اليوم': now.day, 'التاريخ': now.date, 'الوقت': now.time
  });
  invalidateCache_(p.store || 'المرفقات');
  return { ok: true, id: id };
}

/* p.owner: لو انمرّر، ترجع بس المرفقات اللي مالكها يطابقه (مركز/مسؤولة معيّنة تشوف مرفقاتها هي بس).
   لو ما انمرّر (حالة الإدارة)، ترجع كل المرفقات بدون فلترة. */
function getAttachments_(p) {
  let rows = sheetToObjects_((p && p.store) || 'المرفقات');
  if (p && p.owner) {
    const owner = String(p.owner).trim();
    rows = rows.filter(function (r) { return String(r['المالك'] || '').trim() === owner; });
  }
  return { ok: true, attachments: rows.reverse() };
}

function deleteAttachment_(p) {
  const sh = sheet_(p.store || 'المرفقات');
  sh.deleteRow(Number(p.row));
  invalidateCache_(p.store || 'المرفقات');
  return { ok: true };
}

/* ------------------- الإعلانات الهامة (إدارة → مراكز/مسؤولات) ------------------- */
/* p.text: نص الإعلان. p.all: true لو يُنشر لكل المراكز والمسؤولات.
   لو p.all غير موجود/false: p.centers مصفوفة أسماء مراكز مستهدفة، p.masoulat مصفوفة أسماء مسؤولات مستهدفات
   (يمديها الاثنين مع بعض بنفس الإعلان). لو الاثنين فاضيين يتحول تلقائياً لـ"الكل". */
function recordAnnouncement_(p) {
  const sh = sheet_('الإعلانات الهامة');
  const id = Utilities.getUuid();
  const now = nowParts_();
  let targets = 'الكل';
  if (!p.all) {
    const list = [];
    (p.centers || []).forEach(function (c) { if (c) list.push('مركز:' + c); });
    (p.masoulat || []).forEach(function (m) { if (m) list.push('مسؤولة:' + m); });
    targets = list.length ? list.join('|') : 'الكل';
  }
  appendRowByHeaders_(sh, {
    'معرف': id, 'النص': p.text || '', 'استهداف': targets, 'من': p.from || 'الإدارة',
    'اليوم': now.day, 'التاريخ': now.date, 'الوقت': now.time
  });
  invalidateCache_('الإعلانات الهامة');
  return { ok: true, id: id };
}

/* لوحة الإدارة: ترجع كل الإعلانات (بدون فلترة) لعرضها وحذفها. */
function getAllAnnouncements_() {
  const rows = sheetToObjects_('الإعلانات الهامة');
  return { ok: true, announcements: rows.reverse() };
}

/* p.center و/أو p.masoula: ترجع بس الإعلانات اللي تخص هذا المركز/المسؤولة، أو اللي استهدافها "الكل". */
function getAnnouncementsFor_(p) {
  const rows = sheetToObjects_('الإعلانات الهامة');
  const center = p && p.center ? String(p.center).trim() : '';
  const masoula = p && p.masoula ? String(p.masoula).trim() : '';
  const matched = rows.filter(function (r) {
    const target = String(r['استهداف'] || '').trim();
    if (target === 'الكل' || !target) return true;
    const tokens = target.split('|');
    return tokens.some(function (t) {
      if (center && t === 'مركز:' + center) return true;
      if (masoula && t === 'مسؤولة:' + masoula) return true;
      return false;
    });
  });
  return { ok: true, announcements: matched.reverse() };
}

function deleteAnnouncement_(p) {
  const sh = sheet_('الإعلانات الهامة');
  sh.deleteRow(Number(p.row));
  invalidateCache_('الإعلانات الهامة');
  return { ok: true };
}

/* ------------------- محاضر الاجتماعات (إدارة → مراكز/مسؤولات) -------------------
   نفس منطق استهداف الإعلانات الهامة بالضبط (p.all أو p.centers/p.masoulat).
   نقاط الاجتماع والمشاركات والروابط تُحفظ كنص JSON بعمود واحد، وتُفكّ بالواجهة عند العرض/الطباعة. */
function recordMeetingMinutes_(p) {
  const sh = sheet_('محاضر الاجتماعات');
  const id = Utilities.getUuid();
  const now = nowParts_();
  let targets = 'الكل';
  if (!p.all) {
    const list = [];
    (p.centers || []).forEach(function (c) { if (c) list.push('مركز:' + c); });
    (p.masoulat || []).forEach(function (m) { if (m) list.push('مسؤولة:' + m); });
    targets = list.length ? list.join('|') : 'الكل';
  }
  appendRowByHeaders_(sh, {
    'معرف': id,
    'رقم الاجتماع': p.number || '',
    'يوم الاجتماع': p.day || '',
    'تاريخ الاجتماع الهجري': p.hijriDate || '',
    'طريقة الانعقاد': p.method || '',
    'نقاط الاجتماع': JSON.stringify(p.points || []),
    'المشاركات': JSON.stringify(p.participants || []),
    'الروابط': JSON.stringify(p.links || []),
    'اسم الرئيسة': p.headName || '',
    'توقيع الرئيسة': p.headSignature || '',
    'حجم توقيع الرئيسة': p.headSigScale || '',
    'اسم المساعدة': p.assistantName || '',
    'توقيع المساعدة': p.assistantSignature || '',
    'حجم توقيع المساعدة': p.assistantSigScale || '',
    'استهداف': targets, 'من': p.from || 'الإدارة',
    'اليوم': now.day, 'التاريخ': now.date, 'الوقت': now.time
  });
  invalidateCache_('محاضر الاجتماعات');
  return { ok: true, id: id };
}

/* لوحة الإدارة: كل المحاضر بدون فلترة، لعرضها وحذفها */
function getAllMeetingMinutes_() {
  const rows = sheetToObjects_('محاضر الاجتماعات');
  return { ok: true, minutes: rows.reverse() };
}

/* p.center و/أو p.masoula: ترجع بس المحاضر اللي تخص هذا المركز/المسؤولة، أو اللي استهدافها "الكل" */
function getMeetingMinutesFor_(p) {
  const rows = sheetToObjects_('محاضر الاجتماعات');
  const center = p && p.center ? String(p.center).trim() : '';
  const masoula = p && p.masoula ? String(p.masoula).trim() : '';
  const matched = rows.filter(function (r) {
    const target = String(r['استهداف'] || '').trim();
    if (target === 'الكل' || !target) return true;
    const tokens = target.split('|');
    return tokens.some(function (t) {
      if (center && t === 'مركز:' + center) return true;
      if (masoula && t === 'مسؤولة:' + masoula) return true;
      return false;
    });
  });
  return { ok: true, minutes: matched.reverse() };
}

function deleteMeetingMinutes_(p) {
  const sh = sheet_('محاضر الاجتماعات');
  sh.deleteRow(Number(p.row));
  invalidateCache_('محاضر الاجتماعات');
  return { ok: true };
}

/* ------------------- قائمة الأسعار (قائمة المقصف) ------------------- */
/* الكل (مراكز/مسؤولات/إدارة) يشوفون القائمة. الإضافة/التعديل/الحذف مسموحة للإدارة دايماً،
   ولمسؤولة وحدة واحدة تحددها الإدارة (تُحفظ بشيت "الإعدادات"). */

function getPriceItems_() {
  const rows = sheetToObjects_('قائمة الأسعار');
  rows.sort(function (a, b) { return (Number(a['ترتيب']) || 0) - (Number(b['ترتيب']) || 0); });
  return { ok: true, items: rows };
}

/* تتأكد إن اللي يحاول يعدّل مسموح له: إما 'admin'، أو مسؤولة اسمها يطابق
   المسؤولة المخوّلة المحفوظة بشيت الإعدادات. */
function checkPriceListPermission_(actor) {
  if (actor === 'admin') return true;
  const manager = getSettingValue_('مسؤولة قائمة الأسعار');
  return !!manager && String(actor || '').trim() === manager;
}

function addPriceItem_(p) {
  if (!checkPriceListPermission_(p.actor)) return { ok: false, error: 'ما عندك صلاحية تعديل قائمة الأسعار' };
  const sh = sheet_('قائمة الأسعار');
  const id = Utilities.getUuid();
  const lastRow = sh.getLastRow();
  const order = lastRow; // أول صف بعد الهيدر يصير ترتيبه = عدد الصفوف الحالية
  appendRowByHeaders_(sh, {
    'معرف': id, 'التصنيف': p.category || '', 'اسم الصنف': p.name || '', 'السعر': p.price || '', 'ترتيب': order
  });
  invalidateCache_('قائمة الأسعار');
  return { ok: true, id: id };
}

function updatePriceItem_(p) {
  if (!checkPriceListPermission_(p.actor)) return { ok: false, error: 'ما عندك صلاحية تعديل قائمة الأسعار' };
  const sh = sheet_('قائمة الأسعار');
  const row = Number(p.row);
  if (p.category !== undefined) sh.getRange(row, colIndex_(sh, 'التصنيف')).setValue(p.category);
  if (p.name !== undefined) sh.getRange(row, colIndex_(sh, 'اسم الصنف')).setValue(p.name);
  if (p.price !== undefined) sh.getRange(row, colIndex_(sh, 'السعر')).setValue(p.price);
  invalidateCache_('قائمة الأسعار');
  return { ok: true };
}

function deletePriceItem_(p) {
  if (!checkPriceListPermission_(p.actor)) return { ok: false, error: 'ما عندك صلاحية تعديل قائمة الأسعار' };
  const sh = sheet_('قائمة الأسعار');
  sh.deleteRow(Number(p.row));
  invalidateCache_('قائمة الأسعار');
  return { ok: true };
}

/* -------- شيت "الإعدادات" - مفتاح/قيمة عام، مستخدم حالياً بس لتحديد مسؤولة قائمة الأسعار -------- */
function getSettingValue_(key) {
  const rows = sheetToObjects_('الإعدادات');
  const found = rows.find(function (r) { return String(r['المفتاح'] || '').trim() === key; });
  return found ? String(found['القيمة'] || '').trim() : '';
}

function setSettingValue_(key, value) {
  const sh = sheet_('الإعدادات');
  const data = sh.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]).trim() === key) {
      sh.getRange(i + 1, 2).setValue(value);
      invalidateCache_('الإعدادات');
      return;
    }
  }
  sh.appendRow([key, value]);
  invalidateCache_('الإعدادات');
}

function getPriceListManager_() {
  return { ok: true, masoula: getSettingValue_('مسؤولة قائمة الأسعار') };
}

function setPriceListManager_(p) {
  setSettingValue_('مسؤولة قائمة الأسعار', p.masoula || '');
  return { ok: true };
}

/* -------- ملف/رابط قائمة الأسعار (يظهر للجميع، الإدارة فقط تضيفه/تعدّله) -------- */
function getPriceListFile_() {
  return {
    ok: true,
    link: getSettingValue_('رابط ملف قائمة الأسعار'),
    label: getSettingValue_('اسم ملف قائمة الأسعار')
  };
}

function setPriceListFile_(p) {
  if (p.actor !== 'admin') return { ok: false, error: 'ما عندك صلاحية تعديل ملف قائمة الأسعار' };
  let link = '';
  if (p.kind === 'file') {
    link = saveAttachmentFile_(p.fileData, p.fileName || 'ملف قائمة الأسعار', p.mimeType || '');
  } else {
    link = p.link || '';
  }
  setSettingValue_('رابط ملف قائمة الأسعار', link);
  setSettingValue_('اسم ملف قائمة الأسعار', p.label || p.fileName || '');
  return { ok: true };
}

// تشغّل مرة وحدة (اختياري): تصلح روابط الصور القديمة المحفوظة بشيت "الإشعارات"
// اللي كانت بالصيغة الغلط (drive.google.com/file/d/.../view) وتحوّلها للصيغة الصحيحة
function fixOldImageUrls() {
  const sh = sheet_('الإشعارات');
  if (!sh || sh.getLastRow() < 2) { notify_('لا يوجد بيانات لتصليحها'); return; }
  const headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
  const urlCols = ['رابط صورة الإشعار', 'رابط صورة الإشعار الموقع'];
  const range = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn());
  const values = range.getValues();
  let fixed = 0;
  headers.forEach(function (h, idx) {
    if (urlCols.indexOf(h) === -1) return;
    for (let i = 0; i < values.length; i++) {
      const v = values[i][idx];
      const match = /drive\.google\.com\/file\/d\/([^/]+)\//.exec(v);
      if (match) {
        values[i][idx] = 'https://lh3.googleusercontent.com/d/' + match[1];
        fixed++;
      }
    }
  });
  range.setValues(values);
  invalidateCache_('الإشعارات');
  notify_('تم تصليح ' + fixed + ' رابط صورة قديم.');
}

/* تشغّل مرة وحدة (اختياري): تصلح صفوف "المبيعات" اللي انكتبت بترتيب أعمدة غلط
   (كان فيها خلل قديم يخلي المبلغ ينكتب تحت عمود "اليوم" وهكذا بالتسلسل).
   تتعرف على الصفوف المتضررة بنمط واضح: عمود "المبلغ" فيه وقت (مثل 14:05) بدل رقم،
   وعمود "اليوم" فيه رقم بدل اسم يوم، وعمود "التاريخ" فيه اسم يوم بدل تاريخ - وترجع كل قيمة لعمودها الصحيح. */
function fixMisalignedSalesRows_() {
  const sh = sheet_('المبيعات');
  if (!sh || sh.getLastRow() < 2) { notify_('لا يوجد بيانات لتصليحها'); return; }

  const dayCol = colIndex_(sh, 'اليوم');
  const dateCol = colIndex_(sh, 'التاريخ');
  const timeCol = colIndex_(sh, 'الوقت');
  const amountCol = colIndex_(sh, 'المبلغ');
  if ([dayCol, dateCol, timeCol, amountCol].indexOf(-1) !== -1) {
    notify_('تعذر إيجاد كل الأعمدة المطلوبة (اليوم/التاريخ/الوقت/المبلغ) بشيت المبيعات.');
    return;
  }

  const range = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn());
  const values = range.getValues();
  const timePattern = /^\d{1,2}:\d{2}$/;
  const dayNames = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  let fixed = 0;

  values.forEach(function (row) {
    const amountVal = row[amountCol - 1];
    const dayVal = row[dayCol - 1];
    const dateVal = row[dateCol - 1];
    const timeVal = row[timeCol - 1];

    const amountLooksLikeTime = timePattern.test(String(amountVal).trim());
    const dayLooksNumeric = dayVal !== '' && dayVal !== null && !isNaN(parseFloat(dayVal));
    const dateLooksLikeDayName = dayNames.indexOf(String(dateVal).trim()) !== -1;

    // نصلح الصف بس لو انطبقت كل علامات الخلل الثلاث سوا - تفادياً لتعديل صفوف سليمة بالغلط
    if (amountLooksLikeTime && dayLooksNumeric && dateLooksLikeDayName) {
      row[dayCol - 1] = dateVal;   // كان فيه اسم اليوم أصلاً
      row[dateCol - 1] = timeVal;  // كان فيه التاريخ أصلاً
      row[timeCol - 1] = amountVal; // كان فيه الوقت أصلاً
      row[amountCol - 1] = dayVal; // كان فيه المبلغ أصلاً
      fixed++;
    }
  });

  range.setValues(values);
  invalidateCache_('المبيعات');
  notify_('تم تصليح ' + fixed + ' صف من صفوف المبيعات المتضررة.');
}


/* تشغّل مرة وحدة (اختياري): تعبّي عمود "اليوم" لأي صف قديم فاضي فيه، بالاعتماد
   على عمود "التاريخ" بنفس الصف. تستخدمينها لو لاحظتِ إن اسم اليوم ما ينكتب
   بالمبيعات/المرتجعات/الفواتير (سواء لصفوف قديمة، أو لأن عمود "اليوم" ما كان
   موجود أصلاً بالشيت وقت ما انسجلت هذي الصفوف). */
function fillMissingDayNames_() {
  const sheetNames = ['المبيعات', 'المرتجعات', 'الفواتير'];
  let totalFixed = 0;
  const missingSheets = [];
  sheetNames.forEach(function (name) {
    const sh = sheet_(name);
    if (!sh) return;
    const dayCol = colIndex_(sh, 'اليوم');
    const dateCol = colIndex_(sh, 'التاريخ');
    if (dayCol === -1 || dateCol === -1) { missingSheets.push(name); return; }
    if (sh.getLastRow() < 2) return;
    const range = sh.getRange(2, 1, sh.getLastRow() - 1, sh.getLastColumn());
    const values = range.getValues();
    let fixed = 0;
    values.forEach(function (row) {
      const dayVal = String(row[dayCol - 1]).trim();
      const dateVal = row[dateCol - 1];
      if (!dayVal && dateVal) {
        row[dayCol - 1] = dayNameForDateStr_(String(dateVal));
        fixed++;
      }
    });
    if (fixed > 0) range.setValues(values);
    invalidateCache_(name);
    totalFixed += fixed;
  });
  let msg = 'تم تعبئة اسم اليوم لـ ' + totalFixed + ' صف كان فاضي.';
  if (missingSheets.length) {
    msg += '\n\nتنبيه: عمود "اليوم" أو "التاريخ" غير موجود أصلاً بشيت: ' + missingSheets.join('، ') + '. شغّلي دالة setup أولاً لإضافته، ثم أعيدي تشغيل هذي الدالة.';
  }
  notify_(msg);
}

/* تشغّل مرة وحدة (تشخيص): تطلع لك بالضبط أسماء أعمدة شيتات المبيعات/المرتجعات/الفواتير،
   كل اسم عمود بين قوسين [ ] عشان توضّح أي مسافة خفية بأول أو آخر الاسم، وتحدد
   أي عمود هو "اليوم" اللي يتعرف عليه الكود فعلياً. شغليها لو مازال اليوم ما ينكتب
   بعد تشغيل setup و fillMissingDayNames، وابعتيلي محتوى الرسالة اللي تطلع لك. */
function debugDayColumn_() {
  const names = ['المبيعات', 'المرتجعات', 'الفواتير'];
  let msg = '';
  names.forEach(function (name) {
    const sh = sheet_(name);
    if (!sh) { msg += name + ': ⚠️ الشيت غير موجود\n\n'; return; }
    const headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
    const foundCol = colIndex_(sh, 'اليوم');
    msg += name + ' (يجدها الكود بعمود رقم: ' + (foundCol === -1 ? 'ما لقاها ❌' : foundCol) + '):\n';
    headers.forEach(function (h, i) {
      const isMatch = String(h).trim() === 'اليوم';
      msg += '  عمود ' + (i + 1) + ': [' + h + ']' + (isMatch ? '  ← تطابق مع "اليوم"' : '') + '\n';
    });
    // نموذج: وش راح ينكتب لو سجّلنا صف اليوم بالضبط
    msg += '  مثال: اسم اليوم المحسوب لتاريخ اليوم = ' + dayNameForDateStr_(nowParts_().date) + '\n\n';
  });
  notify_(msg);
}

function sheet_(name) {
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
}

/* ------------------- تخزين مؤقت (Cache) لتسريع القراءة ------------------- */
const CACHE_SECONDS = 90;           // شيتات متغيّرة (مبيعات، إشعارات، فواتير، مرتجعات، حضور...)
const CACHE_SECONDS_LONG = 300;     // شيتات شبه ثابتة (المراكز، المسؤولات) - 5 دقائق فقط (كانت 6 ساعات)

function getCache_() {
  return CacheService.getScriptCache();
}

function invalidateCache_(name) {
  try { getCache_().remove('sheet_' + name); } catch (e) {}
}

/* شغّليها يدوياً من قائمة الدوال أعلى المحرر (▶️ Run) في أي وقت بعد ما تعدّلي
   شيت "المسؤولات" أو "المراكز" يدوياً، عشان التغييرات تنعكس بالموقع فوراً
   بدون ما تنتظري وقت الكاش. */
function clearCache() {
  const cache = getCache_();
  ['المسؤولات', 'المراكز', 'المبيعات', 'المرتجعات', 'الفواتير', 'الحضور', 'التعهد', 'المهام', 'الإشعارات'].forEach(function (n) {
    cache.remove('sheet_' + n);
  });
  notify_('تم تفريغ الذاكرة المؤقتة. جربي الدخول بالموقع الحين.');
}

/* ------------------- الأرشفة الحقيقية (نقل فعلي بدل التوسيم بس) -------------------
   قبل هذا التعديل كانت "الأرشفة" توسيم بس (تكتب اسم الفصل بعمود الفصل الدراسي)
   والبيانات القديمة تضل بنفس الشيت الحيّ للأبد، فيكبر حجمه مع كل فصل جديد ويصير
   كل طلب (حتى لو للفصل الحالي بس) يقرأ تاريخ النظام كامل من أول يوم. الحين
   الأرشفة تنقل الصفوف فعلياً لشيت منفصل اسمه "أرشيف_<اسم الشيت>"، فيبقى الشيت
   الحيّ يحتوي بيانات الفصل الحالي بس وصغير دايماً. */
const ARCHIVE_PREFIX = 'أرشيف_';

function getOrCreateArchiveSheet_(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const archiveName = ARCHIVE_PREFIX + name;
  let sh = ss.getSheetByName(archiveName);
  if (!sh) {
    sh = ss.insertSheet(archiveName);
    const live = sheet_(name);
    if (live && live.getLastColumn() > 0) {
      const headers = live.getRange(1, 1, 1, live.getLastColumn()).getValues()[0];
      sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    }
  }
  return sh;
}

/* تنقل من الشيت الحيّ كل صف يحقق matchFn(قيمة عمود الأرشفة) لشيت الأرشيف،
   وتعيد كتابة الشيت الحيّ بالصفوف الباقية بس (بعملية واحدة أسرع من حذف صف صف).
   لو انمرّر newLabel تُكتب هالقيمة بعمود الأرشفة بالصفوف المنقولة قبل نقلها
   (تُستخدم وقت إغلاق فصل حالي: الصفوف الفاضية تتحول لموسومة باسم الفصل).
   بدون newLabel تُنقل الصفوف بقيمتها الحالية كما هي (تُستخدم بالترحيل لمرة وحدة
   للصفوف اللي كانت موسومة قبل بس ما انتقلت فعلياً). */
function archiveRowsMatching_(sh, archiveSh, colIdx, matchFn, newLabel) {
  const lastRow = sh.getLastRow();
  if (lastRow < 2) return 0;
  const numCols = sh.getLastColumn();
  const data = sh.getRange(2, 1, lastRow - 1, numCols).getValues();
  const toArchive = [];
  const keepRows = [];
  for (let i = 0; i < data.length; i++) {
    const row = data[i];
    if (matchFn(row[colIdx - 1])) {
      if (newLabel !== undefined) row[colIdx - 1] = newLabel;
      toArchive.push(row);
    } else {
      keepRows.push(row);
    }
  }
  if (toArchive.length) {
    // لو انضاف عمود جديد للشيت الحيّ بعد ما انعمل شيت الأرشيف (مثل عمود «وقت التسجيل الفعلي»)،
    // نضيف نفس العمود لآخر الأرشيف قبل النقل، وإلا النقل ينهار بسبب اختلاف عدد الأعمدة
    const archCols = archiveSh.getLastColumn();
    if (archCols < numCols) {
      const liveHeaders = sh.getRange(1, 1, 1, numCols).getValues()[0];
      if (archiveSh.getMaxColumns() < numCols) {
        archiveSh.insertColumnsAfter(archiveSh.getMaxColumns(), numCols - archiveSh.getMaxColumns());
      }
      archiveSh.getRange(1, archCols + 1, 1, numCols - archCols).setValues([liveHeaders.slice(archCols)]);
    }
    archiveSh.getRange(archiveSh.getLastRow() + 1, 1, toArchive.length, numCols).setValues(toArchive);
  }
  sh.getRange(2, 1, lastRow - 1, numCols).clearContent();
  if (keepRows.length) {
    sh.getRange(2, 1, keepRows.length, numCols).setValues(keepRows);
  }
  return toArchive.length;
}

/* ترجّع صفوف شيت معيّن حسب الفصل المطلوب:
   - بدون فصل أو "current": صفوف الشيت الحيّ اللي عمود أرشفتها فاضي (الفصل الحالي)
   - "all": كل الصفوف، من الشيت الحيّ + شيت الأرشيف مع بعض
   - اسم فصل محدد: صفوف شيت الأرشيف اللي عمود أرشفتها يساوي هالاسم بالضبط */
function getRowsForTerm_(name, term, archiveCol, cacheSeconds) {
  const col = archiveCol || 'الفصل الدراسي';
  const archiveName = ARCHIVE_PREFIX + name;
  const t = term ? String(term).trim() : '';
  if (!t || t === 'current') {
    return sheetToObjects_(name, cacheSeconds).filter(function (r) { return String(r[col] || '').trim() === ''; });
  }
  if (t === 'all') {
    return sheetToObjects_(name, cacheSeconds).concat(sheetToObjects_(archiveName, cacheSeconds));
  }
  return sheetToObjects_(archiveName, cacheSeconds).filter(function (r) { return String(r[col] || '').trim() === t; });
}

/* دالة ترحيل تُشغَّل يدوياً مرة وحدة بس (من قائمة الدوال أعلى محرر Apps Script):
   تنقل كل الصفوف اللي كانت موسومة قبل باسم فصل (من نظام الأرشفة القديم) من
   الشيتات الحيّة لشيتات الأرشيف المقابلة، فيرجع حجم الشيتات الحيّة صغير فوراً. */
function migrateOldArchivedRowsToArchiveSheets_() {
  const sheetsToMigrate = [
    { name: 'المبيعات', col: 'الفصل الدراسي' },
    { name: 'المرتجعات', col: 'الفصل الدراسي' },
    { name: 'الفواتير', col: 'الفصل الدراسي' },
    { name: 'الإشعارات', col: 'فصل الأرشفة' },
    { name: 'قائمة الدخل', col: 'الفصل الدراسي' }
  ];
  const counts = {};
  sheetsToMigrate.forEach(function (entry) {
    const sh = sheet_(entry.name);
    if (!sh || sh.getLastRow() < 2) { counts[entry.name] = 0; return; }
    const col = colIndex_(sh, entry.col);
    if (col === -1) { counts[entry.name] = 0; return; }
    const archiveSh = getOrCreateArchiveSheet_(entry.name);
    const n = archiveRowsMatching_(sh, archiveSh, col, function (v) { return String(v).trim() !== ''; });
    counts[entry.name] = n;
    invalidateCache_(entry.name);
    invalidateCache_(ARCHIVE_PREFIX + entry.name);
  });
  notify_('تم ترحيل البيانات القديمة لشيتات الأرشيف بنجاح:\n' + JSON.stringify(counts));
}

/* تنسيق التواريخ عند القراءة: قوقل شيتس يحوّل نصوص التاريخ تلقائياً لكائن Date،
   وإذا رجعناه للواجهة كما هو يظهر بصيغة فيها أصفار زايدة (مثل 00:00:00.000Z).
   هذي الدالة تصيغه نص واضح: تاريخ فقط، أو تاريخ ووقت لو فيه وقت فعلي. */
function formatSheetDate_(d) {
  const tz = Session.getScriptTimeZone();
  // قيمة وقت فقط (بدون تاريخ حقيقي) يخزّنها قوقل شيتس داخلياً بتاريخ 30 ديسمبر 1899
  const isTimeOnly = d.getFullYear() === 1899 && d.getMonth() === 11 && d.getDate() === 30;
  if (isTimeOnly) return Utilities.formatDate(d, tz, 'HH:mm');
  const hasTime = d.getHours() !== 0 || d.getMinutes() !== 0 || d.getSeconds() !== 0;
  return Utilities.formatDate(d, tz, hasTime ? 'yyyy-MM-dd HH:mm' : 'yyyy-MM-dd');
}

function sheetToObjects_(name, cacheSeconds) {
  const duration = cacheSeconds || CACHE_SECONDS;
  const cache = getCache_();
  const cacheKey = 'sheet_' + name;

  try {
    const cached = cache.get(cacheKey);
    if (cached) return JSON.parse(cached);
  } catch (e) {
    // تجاهل أي خطأ بالكاش وأكملي القراءة العادية من الشيت
  }

  const sh = sheet_(name);
  if (!sh) return [];
  const data = sh.getDataRange().getValues();
  if (!data || data.length < 1) return [];
  const headers = data[0];
  const rows = [];
  for (let i = 1; i < data.length; i++) {
    const obj = {};
    headers.forEach(function (h, idx) {
      let val = data[i][idx];
      if (val instanceof Date) val = formatSheetDate_(val);
      obj[String(h).trim()] = val;
    });
    obj._row = i + 1;
    rows.push(obj);
  }

  try {
    cache.put(cacheKey, JSON.stringify(rows), duration);
  } catch (e) {
    // إذا كانت البيانات كبيرة جداً على الكاش نتجاهل الخطأ ونكمل بدون تخزين مؤقت
  }

  return rows;
}

/* ------------------- الاسم المعروض للمركز (بدون تغيير الاسم الأصلي) -------------------
   الاسم الأصلي بعمود "اسم المركز" بشيت المراكز هو المفتاح اللي تنربط فيه كل البيانات، فما نلمسه.
   لو عبّيتي عمود "الاسم المعروض" لأي مركز (مثلاً: الأصلي "معهد النور" والمعروض "مركز النور")،
   الموقع يعرض الاسم المعروض بكل مكان، والبيانات تبقى مربوطة بالاسم الأصلي.
   الفكرة: عند دخول أي طلب نحوّل الاسم المعروض إلى الأصلي، وعند خروج أي ردّ نحوّل الأصلي إلى المعروض. */
let DISPLAY_MAP_ = null;   // أصلي -> معروض (للردود الخارجة) - يُضبط بكل طلب

function centerAliasMaps_() {
  const maps = { toReal: {}, toDisplay: {}, any: false };
  try {
    const rows = sheetToObjects_('المراكز', CACHE_SECONDS_LONG);
    rows.forEach(function (r) {
      const real = String(r['اسم المركز'] || '').trim();
      const shown = String(r['الاسم المعروض'] || '').trim();
      if (real && shown && shown !== real) {
        maps.toDisplay[real] = shown;
        maps.toReal[shown] = real;
        maps.any = true;
      }
    });
  } catch (e) { /* لو صار خطأ نكمل بدون أسماء معروضة */ }
  return maps;
}

function mapCenterName_(str, dict) {
  const t = str.trim();
  if (Object.prototype.hasOwnProperty.call(dict, t)) return dict[t];
  // استهداف الإعلانات: "مركز:الاسم|مسؤولة:الاسم"
  if (str.indexOf('مركز:') !== -1 && str.length < 500) {
    return str.split('|').map(function (tok) {
      const t2 = tok.trim();
      if (t2.indexOf('مركز:') === 0) {
        const nm = t2.slice(5);
        if (Object.prototype.hasOwnProperty.call(dict, nm)) return 'مركز:' + dict[nm];
      }
      return tok;
    }).join('|');
  }
  return str;
}

function mapStringsDeep_(v, dict) {
  if (typeof v === 'string') return mapCenterName_(v, dict);
  if (Array.isArray(v)) return v.map(function (x) { return mapStringsDeep_(x, dict); });
  if (v && Object.prototype.toString.call(v) === '[object Object]') {
    const o = {};
    Object.keys(v).forEach(function (k) { o[k] = mapStringsDeep_(v[k], dict); });
    return o;
  }
  return v;
}

function centerDisplay_(name) {
  const n = String(name || '').trim();
  return (DISPLAY_MAP_ && Object.prototype.hasOwnProperty.call(DISPLAY_MAP_, n)) ? DISPLAY_MAP_[n] : name;
}

function json_(obj) {
  if (DISPLAY_MAP_ && Object.keys(DISPLAY_MAP_).length) obj = mapStringsDeep_(obj, DISPLAY_MAP_);
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {
  return handleRequest_(e.parameter);
}

function doPost(e) {
  let params = {};
  try {
    params = JSON.parse(e.postData.contents);
  } catch (err) {
    params = e.parameter;
  }
  return handleRequest_(params);
}

function handleRequest_(p) {
  try {
    const aliasMaps = centerAliasMaps_();
    DISPLAY_MAP_ = aliasMaps.any ? aliasMaps.toDisplay : null;
    if (aliasMaps.any) p = mapStringsDeep_(p, aliasMaps.toReal);   // الاسم المعروض -> الأصلي قبل المعالجة
    const action = p.action;
    switch (action) {
      case 'getCenters': return json_(getCenters_());
      case 'loginCenter': return json_(loginCenter_(p));
      case 'loginMasoula': return json_(loginMasoula_(p));
      case 'getMasoulat': return json_(getMasoulat_());
      case 'getMasoulaGrades': return json_(getMasoulaGrades_(p));
      case 'saveMasoulaGrades': return json_(saveMasoulaGrades_(p));

      case 'recordSale': return json_(recordSale_(p));
      case 'getSales': return json_(getSales_(p));
      case 'updateSale': return json_(updateSale_(p));
      case 'deleteSale': return json_(deleteSale_(p));

      case 'recordReturn': return json_(recordReturn_(p));
      case 'getReturns': return json_(getReturns_(p));
      case 'updateReturn': return json_(updateReturn_(p));
      case 'deleteReturn': return json_(deleteReturn_(p));

      case 'recordInvoice': return json_(recordInvoice_(p));
      case 'getInvoices': return json_(getInvoices_(p));
      case 'updateInvoice': return json_(updateInvoice_(p));
      case 'deleteInvoice': return json_(deleteInvoice_(p));

      case 'getAttendance': return json_(getAttendance_(p));
      case 'recordAttendance': return json_(recordAttendance_(p));
      case 'recordAttendanceBulk': return json_(recordAttendanceBulk_(p));
      case 'getAttendanceForDate': return json_(getAttendanceForDate_(p));

      case 'getPledge': return json_(getPledge_(p));
      case 'signPledge': return json_(signPledge_(p));
      case 'getPledgeStatusAll': return json_(getPledgeStatusAll_());

      case 'getTasksAck': return json_(getTasksAck_(p));
      case 'acknowledgeTasks': return json_(acknowledgeTasks_(p));
      case 'getTasksStatusAll': return json_(getTasksStatusAll_());

      case 'getMasoulaDashboard': return json_(getMasoulaDashboard_(p));

      case 'submitNotice': return json_(submitNotice_(p));
      case 'getCenterNotices': return json_(getCenterNotices_(p));
      case 'getCenterPendingCount': return json_(getCenterPendingCount_(p));
      case 'getPendingNotices': return json_(getPendingNotices_());
      case 'getPendingNoticesCount': return json_(getPendingNoticesCount_());
      case 'getAllNotices': return json_(getAllNotices_(p));
      case 'adminSignNotice': return json_(adminSignNotice_(p));
      case 'updateSignedNotice': return json_(updateSignedNotice_(p));
      case 'getNoticeAdminSignature': return json_(getNoticeAdminSignature_(p));
      case 'updateNotice': return json_(updateNotice_(p));
      case 'deleteNotice': return json_(deleteNotice_(p));

      case 'getStats': return json_(getStats_());
      case 'getSmartAnalysis': return json_(getSmartAnalysis_(p));

      case 'archiveCurrentTerm': return json_(archiveCurrentTerm_(p));
      case 'getTermsList': return json_(getTermsList_());

      case 'recordIncomeItem': return json_(recordIncomeItem_(p));
      case 'getIncomeItems': return json_(getIncomeItems_(p));
      case 'updateIncomeItem': return json_(updateIncomeItem_(p));
      case 'deleteIncomeItem': return json_(deleteIncomeItem_(p));

      case 'recordAttachment': return json_(recordAttachment_(p));
      case 'getAttachments': return json_(getAttachments_(p));
      case 'deleteAttachment': return json_(deleteAttachment_(p));

      case 'recordAnnouncement': return json_(recordAnnouncement_(p));
      case 'getAllAnnouncements': return json_(getAllAnnouncements_());
      case 'getAnnouncementsFor': return json_(getAnnouncementsFor_(p));
      case 'deleteAnnouncement': return json_(deleteAnnouncement_(p));
      case 'recordMeetingMinutes': return json_(recordMeetingMinutes_(p));
      case 'getAllMeetingMinutes': return json_(getAllMeetingMinutes_());
      case 'getMeetingMinutesFor': return json_(getMeetingMinutesFor_(p));
      case 'deleteMeetingMinutes': return json_(deleteMeetingMinutes_(p));

      case 'getPriceItems': return json_(getPriceItems_());
      case 'addPriceItem': return json_(addPriceItem_(p));
      case 'updatePriceItem': return json_(updatePriceItem_(p));
      case 'deletePriceItem': return json_(deletePriceItem_(p));
      case 'getPriceListManager': return json_(getPriceListManager_());
      case 'setPriceListManager': return json_(setPriceListManager_(p));

      case 'getPriceListFile': return json_(getPriceListFile_());
      case 'setPriceListFile': return json_(setPriceListFile_(p));

      case 'loginSupervision': return json_(loginSupervision_(p));
      case 'loginAdmin': return json_(loginAdmin_(p));

      case 'recordDifficulty': return json_(recordDifficulty_(p));
      case 'getDifficulties': return json_(getDifficulties_(p));
      case 'deleteDifficulty': return json_(deleteDifficulty_(p));

      case 'recordIncentiveEntry': return json_(recordIncentiveEntry_(p));
      case 'getIncentiveEntries': return json_(getIncentiveEntries_(p));
      case 'addIncentiveFollowupSplit': return json_(addIncentiveFollowupSplit_(p));
      case 'getIncentiveFollowupSplits': return json_(getIncentiveFollowupSplits_(p));
      case 'deleteIncentiveFollowupSplit': return json_(deleteIncentiveFollowupSplit_(p));

      case 'debugInfo': return json_(debugInfo_());

      default: return json_({ ok: false, error: 'إجراء غير معروف' });
    }
  } catch (err) {
    return json_({ ok: false, error: err.message });
  }
}

/* ------------------- المراكز والمسؤولات: تسجيل الدخول ------------------- */

function getCenters_() {
  const rows = sheetToObjects_('المراكز', CACHE_SECONDS_LONG);
  return { ok: true, centers: rows.map(function (r) { return r['اسم المركز']; }) };
}

function loginCenter_(p) {
  const rows = sheetToObjects_('المراكز', CACHE_SECONDS_LONG);
  const found = rows.find(function (r) {
    return String(r['اسم المركز']).trim() === String(p.center).trim() &&
      String(r['كلمة المرور']).trim() === String(p.password).trim();
  });
  if (!found) return { ok: false, error: 'اسم المركز أو كلمة المرور غير صحيحة' };
  const readOnly = String(found['وضع العرض فقط'] || '').trim() === 'نعم';
  return { ok: true, center: found['اسم المركز'], readOnly: readOnly };
}

function loginMasoula_(p) {
  const rows = sheetToObjects_('المسؤولات', CACHE_SECONDS_LONG);
  const username = String(p.username || '').trim();
  const password = String(p.password || '').trim();

  const nameMatch = rows.find(function (r) {
    return String(r['الاسم']).trim() === username ||
      String(r['البريد الإلكتروني']).trim().toLowerCase() === username.toLowerCase();
  });

  if (!nameMatch) {
    return { ok: false, error: 'ما لقينا اسم "' + username + '" بشيت المسؤولات. تأكدي إنه مكتوب بالضبط نفس الشيت (بدون مسافات زايدة).' };
  }
  if (String(nameMatch['كلمة المرور']).trim() !== password) {
    return { ok: false, error: 'الاسم صحيح، بس كلمة المرور مو مطابقة لللي بالشيت لهذا الاسم.' };
  }

  return { ok: true, name: nameMatch['الاسم'], email: nameMatch['البريد الإلكتروني'] || '', center: nameMatch['اسم المركز'] || '' };
}

function getMasoulat_() {
  const rows = sheetToObjects_('المسؤولات', CACHE_SECONDS_LONG);
  return { ok: true, masoulat: rows.map(function (r) { return r['الاسم']; }).filter(Boolean) };
}

/* ------------------- درجات المسؤولات (تقييم نهاية الفصل من 13) -------------------
   التقييم يدوي بالكامل من لوحة الإدارة (edara.html ← «درجات المسؤولات»): كل بند يكون
   «مكتمل» أو «ناقص»، والدرجة = 13 ناقص درجات البنود الناقصة. تُحفظ بشيت «درجات المسؤولات»
   بصف واحد لكل (فصل + مسؤولة)، ولو انحفظ نفس الفصل مرة ثانية تتحدّث الصفوف نفسها (ما تتكرر). */
const GRADES_SHEET_ = 'درجات المسؤولات';
const GRADES_ITEMS_ = [
  { key: 'تسجيل المبيعات', max: 4 },
  { key: 'الفواتير', max: 3 },
  { key: 'إشعار الاستلام', max: 2 },
  { key: 'توقيع التعهد', max: 2 },
  { key: 'تأكيد الاطلاع على المهام', max: 2 }
];
const GRADES_TOTAL_ = 13;
const GRADES_HEADERS_ = ['معرف', 'الفصل', 'اسم المسؤولة', 'اسم المركز']
  .concat(GRADES_ITEMS_.map(function (i) { return i.key; }))
  .concat(['الدرجة', 'الناقص', 'اليوم', 'التاريخ']);

/* تنشئ الشيت تلقائياً لو ما كان موجود (فما يلزم تشغيل setup() عشان تشتغل الميزة) */
function getGradesSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(GRADES_SHEET_);
  if (!sh) {
    sh = ss.insertSheet(GRADES_SHEET_);
    sh.appendRow(GRADES_HEADERS_);
    sh.getRange(1, 1, 1, GRADES_HEADERS_.length).setFontWeight('bold');
    sh.setRightToLeft(true);
    ['اليوم', 'التاريخ'].forEach(function (h) {
      const idx = GRADES_HEADERS_.indexOf(h) + 1;
      sh.getRange(2, idx, Math.max(sh.getMaxRows() - 1, 1), 1).setNumberFormat('@');
    });
  }
  return sh;
}

/* تحسب الدرجة والناقص من حالات البنود (أي قيمة غير «ناقص» تُعتبر «مكتمل») */
function computeGrade_(items) {
  const state = {};
  const missing = [];
  let score = GRADES_TOTAL_;
  GRADES_ITEMS_.forEach(function (it) {
    const isMissing = String((items || {})[it.key] || '').trim() === 'ناقص';
    state[it.key] = isMissing ? 'ناقص' : 'مكتمل';
    if (isMissing) { score -= it.max; missing.push(it.key); }
  });
  return { state: state, missing: missing, score: score };
}

/* p.term: اسم الفصل، مثال «الفصل الدراسي الأول ١٤٤٨هـ».
   ترجع كل المسؤولات (من شيت المسؤولات) ومعها درجاتهم المحفوظة لهذا الفصل،
   والمسؤولة اللي ما انحفظ لها شي تطلع «مكتمل» بكل البنود (saved: false). */
function getMasoulaGrades_(p) {
  const term = String(p.term || '').trim();
  const masoulat = sheetToObjects_('المسؤولات', CACHE_SECONDS_LONG).filter(function (r) {
    return String(r['الاسم'] || '').trim();
  });

  const savedByName = {};
  if (term) {
    sheetToObjects_(GRADES_SHEET_).forEach(function (r) {
      if (String(r['الفصل'] || '').trim() === term) savedByName[String(r['اسم المسؤولة'] || '').trim()] = r;
    });
  }

  const list = masoulat.map(function (m) {
    const name = String(m['الاسم']).trim();
    const saved = savedByName[name];
    const items = {};
    GRADES_ITEMS_.forEach(function (it) { items[it.key] = saved ? saved[it.key] : 'مكتمل'; });
    const g = computeGrade_(items);
    return {
      name: name,
      center: String(m['اسم المركز'] || '').trim(),
      saved: !!saved,
      items: g.state,
      score: g.score,
      missing: g.missing
    };
  });

  return { ok: true, term: term, total: GRADES_TOTAL_, items: GRADES_ITEMS_, list: list };
}

/* p.term + p.grades: [{ name, center, items: { «تسجيل المبيعات»: 'مكتمل'|'ناقص', ... } }]
   تحدّث الصف الموجود لنفس (الفصل + المسؤولة) أو تضيف صف جديد، والدرجة تنحسب هنا بالسيرفر. */
function saveMasoulaGrades_(p) {
  const term = String(p.term || '').trim();
  if (!term) return { ok: false, error: 'اسم الفصل الدراسي مطلوب' };
  const grades = p.grades || [];
  if (!grades.length) return { ok: false, error: 'لا يوجد درجات للحفظ' };

  const sh = getGradesSheet_();

  // نتأكد أن كل الأعمدة المطلوبة موجودة (لو انضاف الشيت يدوياً أو نقص منه عمود)
  const headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function (h) { return String(h).trim(); });
  GRADES_HEADERS_.forEach(function (h) {
    if (headers.indexOf(h) === -1) {
      sh.getRange(1, sh.getLastColumn() + 1).setValue(h).setFontWeight('bold');
      headers.push(h);
    }
  });
  const termCol = headers.indexOf('الفصل');
  const nameCol = headers.indexOf('اسم المسؤولة');
  const idCol = headers.indexOf('معرف');

  const lastRow = sh.getLastRow();
  const values = lastRow > 1 ? sh.getRange(2, 1, lastRow - 1, headers.length).getValues() : [];
  const rowIndexByKey = {};
  values.forEach(function (row, i) {
    rowIndexByKey[String(row[termCol]).trim() + '||' + String(row[nameCol]).trim()] = i;
  });

  const now = nowParts_();
  const newRows = [];
  let updated = 0;

  grades.forEach(function (g) {
    const name = String(g.name || '').trim();
    if (!name) return;
    const calc = computeGrade_(g.items);
    const fields = {
      'الفصل': term,
      'اسم المسؤولة': name,
      'اسم المركز': String(g.center || '').trim(),
      'الدرجة': calc.score,
      'الناقص': calc.missing.length ? calc.missing.join('، ') : 'مكتمل',
      'اليوم': now.day,
      'التاريخ': now.date
    };
    GRADES_ITEMS_.forEach(function (it) { fields[it.key] = calc.state[it.key]; });

    const key = term + '||' + name;
    if (rowIndexByKey.hasOwnProperty(key)) {
      const row = values[rowIndexByKey[key]];
      headers.forEach(function (h, c) { if (fields.hasOwnProperty(h)) row[c] = fields[h]; });
      updated++;
    } else {
      const row = headers.map(function (h) { return fields.hasOwnProperty(h) ? fields[h] : ''; });
      row[idCol] = Utilities.getUuid();
      newRows.push(row);
    }
  });

  if (updated && values.length) sh.getRange(2, 1, values.length, headers.length).setValues(values);
  if (newRows.length) sh.getRange(sh.getLastRow() + 1, 1, newRows.length, headers.length).setValues(newRows);

  invalidateCache_(GRADES_SHEET_);
  return { ok: true, added: newRows.length, updated: updated };
}

/* تسجيل دخول مكتب إشراف الداخل (eshraf.html) بالبريد الإلكتروني وكلمة المرور -
   البيانات تُدارى يدوياً بشيت "دخول الإشراف" (تضيفين صف جديد لكل بريد مسموح له بالدخول). */
function loginSupervision_(p) {
  const rows = sheetToObjects_('دخول الإشراف', CACHE_SECONDS_LONG);
  const email = String(p.email || '').trim().toLowerCase();
  const password = String(p.password || '').trim();

  const found = rows.find(function (r) {
    return String(r['البريد الإلكتروني']).trim().toLowerCase() === email;
  });

  if (!found) {
    return { ok: false, error: 'ما لقينا هذا البريد الإلكتروني بشيت "دخول الإشراف". تأكدي إنه مضاف ومكتوب بالضبط.' };
  }
  if (String(found['كلمة المرور']).trim() !== password) {
    return { ok: false, error: 'البريد الإلكتروني صحيح، بس كلمة المرور مو مطابقة.' };
  }
  return { ok: true, email: found['البريد الإلكتروني'], name: found['الاسم'] || '' };
}

/* تسجيل دخول لوحة إدارة وحدة المقاصف (edara.html) - كلمة المرور مخزّنة بـ
   "Script Properties" (إعدادات المشروع بمحرر Apps Script)، مو بالكود نفسه،
   عشان ما تظهر بملفات edara.html أو Code.gs المرفوعة على GitHub.
   طريقة الإضافة/التعديل: من محرر Apps Script ← أيقونة الترس (⚙️ Project Settings)
   يسار الشاشة ← "Script Properties" ← Add script property ←
   Property: ADMIN_PASSWORD, Value: كلمة المرور اللي تبينها ← Save. */
function loginAdmin_(p) {
  const password = String(p.password || '').trim();
  const stored = PropertiesService.getScriptProperties().getProperty('ADMIN_PASSWORD');
  if (!stored) {
    return { ok: false, error: 'ما تم ضبط كلمة مرور الإدارة بعد. من محرر Apps Script: ⚙️ Project Settings ← Script Properties ← أضيفي Property باسم ADMIN_PASSWORD وقيمتها كلمة المرور.' };
  }
  if (password !== String(stored).trim()) {
    return { ok: false, error: 'كلمة المرور غير صحيحة' };
  }
  return { ok: true };
}

/* ------------------- المبيعات اليومية ------------------- */

function recordSale_(p) {
  const sh = sheet_('المبيعات');
  const id = Utilities.getUuid();
  const now = nowParts_();
  const date = p.date || now.date;
  const time = p.time || now.time;
  const day = dayNameForDateStr_(date);
  appendRowByHeaders_(sh, {
    'معرف': id, 'اسم المركز': p.center, 'اليوم': day, 'التاريخ': date, 'الوقت': time, 'المبلغ': Number(p.amount),
    'ملاحظات': p.notes || '',
    'وقت التسجيل الفعلي': entryStamp_()   // وقت التسجيل الحقيقي من السيرفر (يعتمد عليه التحليل الذكي لقياس «التسجيل أول بأول»)
  });
  invalidateCache_('المبيعات');
  return { ok: true, id: id };
}

/* p.term: 'current' (افتراضي لو ما انمرّر شي) = بس الصفوف اللي عمود الأرشفة فيها فاضي
   (يعني ما انترحّلت لفصل منتهي بعد). أي قيمة ثانية = اسم فصل محدد بالضبط.
   'all' = كل الصفوف بدون فلترة (تُستخدم لعرض كل التاريخ).
   colName: اسم عمود الأرشفة - افتراضياً "الفصل الدراسي"، وبشيت "الإشعارات" نستخدم
   عمود منفصل اسمه "فصل الأرشفة" لأن "الفصل الدراسي" فيه مستخدم أصلاً لغرض ثاني
   (تسجيل فصل رسوم حفل تحفيظ الصغار وقت إرسال الإشعار). */
function filterByTerm_(rows, term, colName) {
  const col = colName || 'الفصل الدراسي';
  if (term === 'all') return rows;
  if (term && term !== 'current') {
    return rows.filter(function (r) { return String(r[col] || '').trim() === term; });
  }
  return rows.filter(function (r) { return String(r[col] || '').trim() === ''; });
}

/* ترجع قائمة بأسماء الفصول الدراسية المنتهية (اللي سبق ترحيلها) الموجودة فعلياً
   بأي من الشيتات الأربعة، بدون تكرار - تُستخدم لتعبئة قائمة اختيار الفصل بالواجهة. */
function getTermsList_() {
  const seen = {};
  const terms = [];
  function collect(name, colName) {
    // بعد الأرشفة الحقيقية، الفصول المنتهية تُقرأ من شيت الأرشيف (الشيت الحيّ
    // يحتوي الفصل الحالي بس، وما فيه أصلاً قيم فصل غير فاضية لنجمعها)
    sheetToObjects_(ARCHIVE_PREFIX + name).forEach(function (r) {
      const t = String(r[colName] || '').trim();
      if (t && !seen[t]) { seen[t] = true; terms.push(t); }
    });
  }
  collect('المبيعات', 'الفصل الدراسي');
  collect('المرتجعات', 'الفصل الدراسي');
  collect('الفواتير', 'الفصل الدراسي');
  collect('الإشعارات', 'فصل الأرشفة');
  collect('قائمة الدخل', 'الفصل الدراسي');
  return { ok: true, terms: terms };
}

function getSales_(p) {
  let rows = getRowsForTerm_('المبيعات', p.term, 'الفصل الدراسي');
  if (p.center) rows = rows.filter(function (r) { return String(r['اسم المركز']).trim() === String(p.center).trim(); });
  const total = rows.reduce(function (sum, r) { return sum + (Number(r['المبلغ']) || 0); }, 0);
  return { ok: true, sales: rows, total: total };
}

/* كاش بسيط لصف العناوين مدة تنفيذ الطلب الواحد بس (متغيّر عام يُعاد إنشاؤه
   مع كل استدعاء جديد لـ Apps Script). الهدف: دوال مثل updateInvoice_ اللي تنادي
   colIndex_ عدة مرات بنفس الشيت كانت تعيد قراءة صف العناوين من قوقل شيتس بكل
   استدعاء (طلب شبكة منفصل لكل مرة) - الحين تُقرأ مرة وحدة وتُعاد استخدامها. */
var _headerRowCache_ = {};

function getHeaderRow_(sh) {
  const key = sh.getSheetId();
  if (_headerRowCache_[key]) return _headerRowCache_[key];
  const headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
  _headerRowCache_[key] = headers;
  return headers;
}

/* ترجع رقم عمود بالاسم (1-indexed) بالبحث عن اسم العمود بصف العناوين.
   تتجاهل أي مسافات زائدة بأول/آخر اسم العمود بالشيت عشان ما يفشل التطابق
   لو انضاف العمود يدوياً وفيه مسافة خفية (وهذا سبب شائع لمشكلة "اليوم ما ينكتب"). */
function colIndex_(sh, headerName) {
  const headers = getHeaderRow_(sh);
  const target = String(headerName).trim();
  for (let i = 0; i < headers.length; i++) {
    if (String(headers[i]).trim() === target) return i + 1;
  }
  return -1;
}

/* تضيف صف جديد حسب اسم العمود الفعلي بالشيت (مو حسب ترتيب ثابت بالكود).
   هذا يحمينا لو صار ترتيب الأعمدة الفعلي بالشيت مختلف عن الترتيب المتوقع
   (مثلاً لو انضاف عمود جديد بآخر الشيت بدل ما ينحط بمكانه الصحيح) - وهذا بالضبط
   كان سبب مشكلة "المبلغ يتكتب تحت عمود اليوم" اللي صارت قبل هذا الإصلاح.
   تتجاهل أيضاً أي مسافات زائدة بأسماء الأعمدة (نفس سبب مشكلة colIndex_ أعلاه).
   valuesObj: كائن {اسم العمود: القيمة} - أي عمود موجود بالشيت وما انذكر بالكائن يُترك فاضي. */
function appendRowByHeaders_(sh, valuesObj) {
  const headers = getHeaderRow_(sh);
  const keysTrimmed = {};
  Object.keys(valuesObj).forEach(function (k) { keysTrimmed[k.trim()] = valuesObj[k]; });
  const row = headers.map(function (h) {
    const key = String(h).trim();
    return keysTrimmed.hasOwnProperty(key) ? keysTrimmed[key] : '';
  });
  sh.appendRow(row);
}

function updateSale_(p) {
  const sh = sheet_('المبيعات');
  const row = Number(p.row);
  sh.getRange(row, colIndex_(sh, 'المبلغ')).setValue(Number(p.amount));
  if (p.date) {
    sh.getRange(row, colIndex_(sh, 'التاريخ')).setValue(p.date);
    const dayCol = colIndex_(sh, 'اليوم');
    if (dayCol !== -1) sh.getRange(row, dayCol).setValue(dayNameForDateStr_(p.date));
  }
  if (p.notes !== undefined) {
    const notesCol = colIndex_(sh, 'ملاحظات');
    if (notesCol !== -1) sh.getRange(row, notesCol).setValue(p.notes);
  }
  invalidateCache_('المبيعات');
  return { ok: true };
}

function deleteSale_(p) {
  const sh = sheet_('المبيعات');
  sh.deleteRow(Number(p.row));
  invalidateCache_('المبيعات');
  return { ok: true };
}

/* ------------------- البضائع المرتجعة ------------------- */

function recordReturn_(p) {
  const sh = sheet_('المرتجعات');
  const id = Utilities.getUuid();
  const date = p.date || nowParts_().date;
  const day = dayNameForDateStr_(date);
  appendRowByHeaders_(sh, {
    'معرف': id, 'اسم المركز': p.center, 'اليوم': day, 'التاريخ': date,
    'وصف الصنف': p.description || '', 'الكمية': Number(p.quantity) || 0, 'القيمة': Number(p.value) || 0,
    'ملاحظات': p.notes || ''
  });
  invalidateCache_('المرتجعات');
  return { ok: true, id: id };
}

function getReturns_(p) {
  let rows = getRowsForTerm_('المرتجعات', p.term, 'الفصل الدراسي');
  if (p.center) rows = rows.filter(function (r) { return String(r['اسم المركز']).trim() === String(p.center).trim(); });
  const total = rows.reduce(function (sum, r) { return sum + (Number(r['القيمة']) || 0); }, 0);
  return { ok: true, returns: rows, total: total };
}

function updateReturn_(p) {
  const sh = sheet_('المرتجعات');
  const row = Number(p.row);
  if (p.description !== undefined) sh.getRange(row, colIndex_(sh, 'وصف الصنف')).setValue(p.description);
  if (p.quantity !== undefined) sh.getRange(row, colIndex_(sh, 'الكمية')).setValue(Number(p.quantity));
  if (p.value !== undefined) sh.getRange(row, colIndex_(sh, 'القيمة')).setValue(Number(p.value));
  if (p.notes !== undefined) {
    const notesCol = colIndex_(sh, 'ملاحظات');
    if (notesCol !== -1) sh.getRange(row, notesCol).setValue(p.notes);
  }
  invalidateCache_('المرتجعات');
  return { ok: true };
}

function deleteReturn_(p) {
  const sh = sheet_('المرتجعات');
  sh.deleteRow(Number(p.row));
  invalidateCache_('المرتجعات');
  return { ok: true };
}

/* ------------------- بطاقات التحفيز -------------------
   سجل "تسليم": المركز/المسؤولة يسلّمون بطاقة لشخص (معلمة أو غيرها) يوقّع هو بنفسه على الإقرار.
   سجل "استلام": المركز/المسؤولة نفسها تستلم من الإدارة وتوقّع بنفسها (الدور يوضّح مين وقّعت:
   مديرة المركز أو مسؤولة المقصف). كل سطر بطاقة موقّعة (رسم أو صورة)، بدون أرشفة تلقائية.
   متابعة الاستبدال: الكمية المسجّلة بسطر "تسليم" واحد ممكن تتوزّع على أكثر من مستفيدة (مثلاً
   ٧ بطاقات وُزّعت على ٣ طالبات بأعداد مختلفة) - لذا نخزّنها بشيت منفصل "متابعة بطاقات التحفيز"
   كأسطر متعددة لكل سطر تسليم أصلي، ونتحقق دايماً إن مجموع الأعداد الموزّعة ما يتجاوز الكمية
   الأصلية (addIncentiveFollowupSplit_). */
const INCENTIVE_CATEGORIES_ = ['مكافأة', 'هدية'];
const INCENTIVE_PRICES_ = [3, 2];
const INCENTIVE_KINDS_ = ['تسليم', 'استلام'];

function recordIncentiveEntry_(p) {
  const sh = sheet_('بطاقات التحفيز');
  const id = Utilities.getUuid();
  const now = nowParts_();
  const category = p.category;
  const price = Number(p.price) || 0;
  const qty = Number(p.qty) || 0;
  if (!p.center) return { ok: false, error: 'اسم المركز مطلوب' };
  if (INCENTIVE_KINDS_.indexOf(p.kind) === -1) return { ok: false, error: 'نوع السجل غير صحيح' };
  if (INCENTIVE_CATEGORIES_.indexOf(category) === -1) return { ok: false, error: 'نوع البطاقة غير صحيح' };
  if (INCENTIVE_PRICES_.indexOf(price) === -1) return { ok: false, error: 'قيمة البطاقة غير صحيحة' };
  if (!qty || qty < 1) return { ok: false, error: 'الكمية مطلوبة' };
  if (!p.recipientName) return { ok: false, error: 'اسم المستلمة مطلوب' };
  if (!p.signature) return { ok: false, error: 'لازم التوقيع' };
  // البطاقة اللي اتحسمت (سواء بالاستبدال أو بالإرجاع) ترجع متاحة من جديد لمنسوبة ثانية -
  // فالمتاح للتسليم = المستلَم - (المسلَّم كله - المحسوم منه عن طريق المتابعة)
  if (p.kind === 'تسليم') {
    const allRows = sheetToObjects_('بطاقات التحفيز');
    const centerRows = allRows.filter(function (r) {
      return String(r['اسم المركز']).trim() === String(p.center).trim() && r['نوع البطاقة'] === category && Number(r['القيمة']) === price;
    });
    const received = centerRows.filter(function (r) { return r['نوع السجل'] === 'استلام'; }).reduce(function (s, r) { return s + (Number(r['الكمية']) || 0); }, 0);
    const deliveredRows = centerRows.filter(function (r) { return r['نوع السجل'] === 'تسليم'; });
    const deliveredTotal = deliveredRows.reduce(function (s, r) { return s + (Number(r['الكمية']) || 0); }, 0);
    const deliveredIds = deliveredRows.map(function (r) { return r['معرف']; });
    const resolved = sheetToObjects_('متابعة بطاقات التحفيز')
      .filter(function (s) { return deliveredIds.indexOf(s['معرف السطر الأصلي']) !== -1; })
      .reduce(function (s, r) { return s + (Number(r['العدد']) || 0); }, 0);
    const outstanding = deliveredTotal - resolved;
    const available = received - outstanding;
    if (qty > available) {
      return { ok: false, error: 'لا يمكن تسليم كمية أكبر من الكمية المتاحة من فئة ' + category + ' بقيمة (' + cardPriceLabelForServer_(price) + '). الكمية المتاحة حالياً للتسليم: ' + Math.max(0, available) + '.' };
    }
  }
  appendRowByHeaders_(sh, {
    'معرف': id, 'اسم المركز': p.center, 'الدور': p.role || '', 'نوع السجل': p.kind,
    'نوع البطاقة': category, 'القيمة': price, 'الكمية': qty, 'اسم المستلمة': p.recipientName,
    'التوقيع': p.signature, 'اليوم': now.day, 'التاريخ': now.date, 'الوقت': now.time
  });
  invalidateCache_('بطاقات التحفيز');
  return { ok: true, id: id };
}

function cardPriceLabelForServer_(p) { return Number(p) === 3 ? '3 ريال' : 'ريالين'; }

function getIncentiveEntries_(p) {
  let rows = sheetToObjects_('بطاقات التحفيز');
  if (p && p.center) rows = rows.filter(function (r) { return String(r['اسم المركز']).trim() === String(p.center).trim(); });
  if (p && p.kind) rows = rows.filter(function (r) { return r['نوع السجل'] === p.kind; });
  rows.sort(function (a, b) { return String(b['التاريخ'] || '').localeCompare(String(a['التاريخ'] || '')); });
  return { ok: true, list: rows };
}

/* تضيف جزء من الكمية الأصلية (سطر تسليم واحد) باسم مستفيدة معيّنة وحالتها - مع التحقق إن
   المجموع (اللي سبق توزيعه + الجديد) ما يتجاوز الكمية الأصلية بالسطر */
function addIncentiveFollowupSplit_(p) {
  const parent = sheetToObjects_('بطاقات التحفيز').find(function (r) { return r['معرف'] === p.parentId; });
  if (!parent) return { ok: false, error: 'السطر الأصلي غير موجود' };
  const qty = Number(p.qty) || 0;
  if (!qty || qty < 1) return { ok: false, error: 'العدد مطلوب' };
  if (!p.status) return { ok: false, error: 'الحالة مطلوبة' };
  const existing = sheetToObjects_('متابعة بطاقات التحفيز').filter(function (r) { return r['معرف السطر الأصلي'] === p.parentId; });
  const allocated = existing.reduce(function (s, r) { return s + (Number(r['العدد']) || 0); }, 0);
  const total = Number(parent['الكمية']) || 0;
  if (allocated + qty > total) {
    return { ok: false, error: 'المجموع الموزّع (' + (allocated + qty) + ') أكبر من الكمية الأصلية (' + total + ') - المتبقي غير الموزّع: ' + (total - allocated) };
  }
  const sh = sheet_('متابعة بطاقات التحفيز');
  const id = Utilities.getUuid();
  const now = nowParts_();
  appendRowByHeaders_(sh, {
    'معرف': id, 'معرف السطر الأصلي': p.parentId, 'اسم المركز': parent['اسم المركز'],
    'اسم المستفيدة': p.beneficiaryName, 'العدد': qty, 'الحالة': p.status || 'تم استبدال القيمة',
    'اليوم': now.day, 'التاريخ': now.date
  });
  invalidateCache_('متابعة بطاقات التحفيز');
  return { ok: true, id: id };
}

function getIncentiveFollowupSplits_(p) {
  let rows = sheetToObjects_('متابعة بطاقات التحفيز');
  if (p && p.parentId) rows = rows.filter(function (r) { return r['معرف السطر الأصلي'] === p.parentId; });
  if (p && p.center) rows = rows.filter(function (r) { return String(r['اسم المركز']).trim() === String(p.center).trim(); });
  return { ok: true, list: rows };
}

function deleteIncentiveFollowupSplit_(p) {
  const rows = sheetToObjects_('متابعة بطاقات التحفيز');
  const target = rows.find(function (r) { return r['معرف'] === p.id; });
  if (!target) return { ok: false, error: 'السطر غير موجود' };
  const sh = sheet_('متابعة بطاقات التحفيز');
  sh.deleteRow(target._row);
  invalidateCache_('متابعة بطاقات التحفيز');
  return { ok: true };
}

/* ------------------- بيان الفواتير ------------------- */

function recordInvoice_(p) {
  const sh = sheet_('الفواتير');
  const id = Utilities.getUuid();
  const date = p.date || nowParts_().date;
  const day = dayNameForDateStr_(date);
  appendRowByHeaders_(sh, {
    'معرف': id, 'اسم المركز': p.center, 'رقم الفاتورة': p.invoiceNumber || '', 'مصدر الفاتورة': p.invoiceSource || '', 'اليوم': day, 'التاريخ': date,
    'المبلغ الإجمالي': Number(p.totalAmount) || 0, 'الربح': Number(p.profit) || 0, 'ملاحظات': p.notes || ''
  });
  invalidateCache_('الفواتير');
  return { ok: true, id: id };
}

function getInvoices_(p) {
  let rows = getRowsForTerm_('الفواتير', p.term, 'الفصل الدراسي');
  if (p.center) rows = rows.filter(function (r) { return String(r['اسم المركز']).trim() === String(p.center).trim(); });
  const totalAmount = rows.reduce(function (sum, r) { return sum + (Number(r['المبلغ الإجمالي']) || 0); }, 0);
  const totalProfit = rows.reduce(function (sum, r) { return sum + (Number(r['الربح']) || 0); }, 0);
  return { ok: true, invoices: rows, totalAmount: totalAmount, totalProfit: totalProfit };
}

function updateInvoice_(p) {
  const sh = sheet_('الفواتير');
  const row = Number(p.row);
  if (p.invoiceNumber !== undefined) sh.getRange(row, colIndex_(sh, 'رقم الفاتورة')).setValue(p.invoiceNumber);
  if (p.invoiceSource !== undefined) {
    const sourceCol = colIndex_(sh, 'مصدر الفاتورة');
    if (sourceCol !== -1) sh.getRange(row, sourceCol).setValue(p.invoiceSource);
  }
  if (p.date !== undefined && p.date) {
    sh.getRange(row, colIndex_(sh, 'التاريخ')).setValue(p.date);
    const dayCol = colIndex_(sh, 'اليوم');
    if (dayCol !== -1) sh.getRange(row, dayCol).setValue(dayNameForDateStr_(p.date));
  }
  if (p.totalAmount !== undefined) sh.getRange(row, colIndex_(sh, 'المبلغ الإجمالي')).setValue(Number(p.totalAmount));
  if (p.profit !== undefined) sh.getRange(row, colIndex_(sh, 'الربح')).setValue(Number(p.profit));
  if (p.notes !== undefined) {
    const notesCol = colIndex_(sh, 'ملاحظات');
    if (notesCol !== -1) sh.getRange(row, notesCol).setValue(p.notes);
  }
  invalidateCache_('الفواتير');
  return { ok: true };
}

function deleteInvoice_(p) {
  const sh = sheet_('الفواتير');
  sh.deleteRow(Number(p.row));
  invalidateCache_('الفواتير');
  return { ok: true };
}

/* ------------------- حضور الاجتماعات (تسجّله الإدارة) ------------------- */

// تسجيل حضور اسم واحد (أبقيناها للتوافق مع الاستخدامات القديمة)
function recordAttendance_(p) {
  const sh = sheet_('الحضور');
  const now = nowParts_();
  const date = p.date || now.date;
  const time = p.time || now.time;
  const day = dayNameForDateStr_(date);
  appendRowByHeaders_(sh, { 'الاسم': p.name, 'اليوم': day, 'التاريخ': date, 'الوقت': time });
  invalidateCache_('الحضور');
  return { ok: true };
}

// تسجيل حضور عدة مسؤولات دفعة وحدة ليوم معيّن (تُستخدم من لوحة الإدارة)
function recordAttendanceBulk_(p) {
  const sh = sheet_('الحضور');
  const now = nowParts_();
  const date = p.date || now.date;
  const time = now.time;
  const day = dayNameForDateStr_(date);
  let names = p.names;
  if (typeof names === 'string') {
    try { names = JSON.parse(names); } catch (e) { names = [names]; }
  }
  names = names || [];

  // تفادي تكرار تسجيل نفس الاسم بنفس التاريخ
  const existingNames = sheetToObjects_('الحضور').filter(function (r) {
    return r['التاريخ'] === date;
  }).map(function (r) { return r['الاسم']; });

  let added = 0;
  names.forEach(function (name) {
    if (existingNames.indexOf(name) === -1) {
      appendRowByHeaders_(sh, { 'الاسم': name, 'اليوم': day, 'التاريخ': date, 'الوقت': time });
      added++;
    }
  });
  invalidateCache_('الحضور');
  return { ok: true, added: added };
}

function getAttendanceForDate_(p) {
  const date = p.date;
  const rows = sheetToObjects_('الحضور').filter(function (r) { return r['التاريخ'] === date; });
  return { ok: true, names: rows.map(function (r) { return r['الاسم']; }) };
}

function getAttendance_(p) {
  const rows = sheetToObjects_('الحضور').filter(function (r) {
    return String(r['الاسم']).trim() === String(p.name).trim();
  });
  return { ok: true, records: rows };
}

/* ------------------- التعهد السنوي ------------------- */

function signPledge_(p) {
  const sh = sheet_('التعهد');
  const now = nowParts_();
  appendRowByHeaders_(sh, {
    'الاسم': p.name, 'نص التعهد': p.pledgeText, 'اليوم': now.day, 'التاريخ': now.date, 'الوقت': now.time, 'الحالة': 'تم التعهد'
  });
  invalidateCache_('التعهد');
  return { ok: true };
}

function getPledge_(p) {
  const rows = sheetToObjects_('التعهد').filter(function (r) {
    return String(r['الاسم']).trim() === String(p.name).trim();
  });
  const latest = rows.length ? rows[rows.length - 1] : null;
  return { ok: true, pledge: latest };
}

/* تُستخدم بلوحة الإدارة: ترجع لكل مسؤولة مسجّلة بشيت "المسؤولات" حالة تعهدها
   (وقّعت أو لا، وتاريخ آخر توقيع لو وقّعت) - عشان الإدارة تشوف مين وقّعت ومين لسا. */
function getPledgeStatusAll_() {
  const masoulat = sheetToObjects_('المسؤولات', CACHE_SECONDS_LONG);
  const pledgeRows = sheetToObjects_('التعهد');
  const latestByName = {};
  pledgeRows.forEach(function (r) {
    latestByName[String(r['الاسم']).trim()] = r;
  });
  const list = masoulat.map(function (m) {
    const name = String(m['الاسم'] || '').trim();
    const p = latestByName[name];
    return {
      name: name,
      center: m['اسم المركز'] || '',
      signed: !!p,
      day: p ? (p['اليوم'] || '') : '',
      date: p ? (p['التاريخ'] || '') : '',
      time: p ? (p['الوقت'] || '') : ''
    };
  }).filter(function (r) { return r.name; });
  return { ok: true, list: list };
}

/* ------------------- مهام مسؤولة المقصف ------------------- */

/* الاطلاع على المهام يُحفظ ويُتحقق منه بالبريد الإلكتروني (وليس الاسم فقط)،
   عشان لو صار فيه مسؤولتين بنفس الاسم بالضبط، ما يصير خلط بينهن ("فلانة اطلعت"
   وهي أصلاً ما دخلت). الصفوف القديمة اللي ما فيها بريد إلكتروني (قبل هذا التعديل)
   لسا تنطابق بالاسم كحل احتياطي. */
function acknowledgeTasks_(p) {
  const sh = sheet_('المهام');
  const now = nowParts_();
  appendRowByHeaders_(sh, {
    'الاسم': p.name, 'البريد الإلكتروني': p.email || '', 'نص المهام': p.tasksText, 'اليوم': now.day, 'التاريخ': now.date, 'الوقت': now.time, 'الحالة': 'تم الاطلاع'
  });
  invalidateCache_('المهام');
  return { ok: true };
}

function getTasksAck_(p) {
  const email = String(p.email || '').trim().toLowerCase();
  const name = String(p.name || '').trim();
  const rows = sheetToObjects_('المهام').filter(function (r) {
    const rEmail = String(r['البريد الإلكتروني'] || '').trim().toLowerCase();
    if (email && rEmail) return rEmail === email;
    return String(r['الاسم']).trim() === name;
  });
  const latest = rows.length ? rows[rows.length - 1] : null;
  return { ok: true, ack: latest };
}

/* تُستخدم بلوحة الإدارة: ترجع لكل مسؤولة مسجّلة بشيت "المسؤولات" حالة اطلاعها
   على المهام (اطلعت أو لا، وتاريخ آخر اطلاع لو اطلعت) - المطابقة بالبريد الإلكتروني
   أولاً (أدق)، وبالاسم كحل احتياطي للصفوف القديمة اللي ما فيها بريد. */
function getTasksStatusAll_() {
  const masoulat = sheetToObjects_('المسؤولات', CACHE_SECONDS_LONG);
  const taskRows = sheetToObjects_('المهام');
  const latestByEmail = {};
  const latestByName = {};
  taskRows.forEach(function (r) {
    const email = String(r['البريد الإلكتروني'] || '').trim().toLowerCase();
    const name = String(r['الاسم'] || '').trim();
    if (email) latestByEmail[email] = r;
    if (name) latestByName[name] = r;
  });
  const list = masoulat.map(function (m) {
    const name = String(m['الاسم'] || '').trim();
    const email = String(m['البريد الإلكتروني'] || '').trim().toLowerCase();
    const r = (email && latestByEmail[email]) || latestByName[name];
    return {
      name: name,
      center: m['اسم المركز'] || '',
      acknowledged: !!r,
      day: r ? (r['اليوم'] || '') : '',
      date: r ? (r['التاريخ'] || '') : '',
      time: r ? (r['الوقت'] || '') : ''
    };
  }).filter(function (r) { return r.name; });
  return { ok: true, list: list };
}

/* تجمع كل بيانات لوحة مسؤولة المقصف (الحضور + التعهد + اطلاع المهام + عدد الإشعارات المعلّقة)
   بطلب واحد بدل 4 طلبات منفصلة كانت تُرسل عند فتح اللوحة - كل طلب لـ Apps Script فيه تأخير
   بدء تشغيل، فتجميعها بطلب واحد يسرّع فتح لوحة المسؤولة بشكل ملحوظ. */
function getMasoulaDashboard_(p) {
  const name = String(p.name || '').trim();
  const email = String(p.email || '').trim().toLowerCase();

  const attendance = sheetToObjects_('الحضور').filter(function (r) {
    return String(r['الاسم']).trim() === name;
  });
  const pledgeRows = sheetToObjects_('التعهد').filter(function (r) {
    return String(r['الاسم']).trim() === name;
  });
  const tasksRows = sheetToObjects_('المهام').filter(function (r) {
    const rEmail = String(r['البريد الإلكتروني'] || '').trim().toLowerCase();
    if (email && rEmail) return rEmail === email;
    return String(r['الاسم']).trim() === name;
  });
  let pendingCount = 0;
  if (p.center) {
    const notices = sheetToObjects_('الإشعارات').filter(function (r) {
      return String(r['اسم المركز']).trim() === String(p.center).trim() && r['الحالة'] !== 'تم الاطلاع';
    });
    pendingCount = notices.length;
  }
  return {
    ok: true,
    attendance: attendance,
    pledge: pledgeRows.length ? pledgeRows[pledgeRows.length - 1] : null,
    tasksAck: tasksRows.length ? tasksRows[tasksRows.length - 1] : null,
    pendingCount: pendingCount
  };
}

/* ------------------- إشعارات الاستلام والتسليم ------------------- */

function submitNotice_(p) {
  const sh = sheet_('الإشعارات');
  const id = Utilities.getUuid();
  const now = nowParts_();

  // نحفظ صورة الإشعار الكاملة بس (فيها التوقيع أصلاً) - توفير وقت بعدم رفع صورتين لكل إشعار
  const noticeImageUrl = saveImage_(p.noticeImage,
    noticeFileName_('إشعار', p.type, p.center, now.date, id),
    ['الإشعارات', p.center]);

  appendRowByHeaders_(sh, {
    'معرف': id, 'النوع': p.type, 'اسم المركز': p.center,
    'يوم الإرسال': now.day, 'تاريخ الإرسال': now.date, 'وقت الإرسال': now.time,
    'اسم المسلّمة': p.senderName || '', 'المبلغ': p.amount,
    'الشهر': p.month || '', 'الفصل الدراسي': p.term || '', 'العام': p.year || '',
    'بيان مخصص': p.reason || '',
    'رابط صورة الإشعار': noticeImageUrl, 'الحالة': 'بانتظار الاطلاع',
    'بيانات توقيع المركز': p.signature || ''
  });
  invalidateCache_('الإشعارات');

  notifyAdminNewNotice_(p.type, p.center, p.amount, now, noticeImageUrl, p.senderName);

  return { ok: true, id: id };
}

function notifyAdminNewNotice_(type, center, amount, now, noticeImageUrl, senderName) {
  center = centerDisplay_(center);
  if (!ADMIN_NOTIFY_EMAIL || ADMIN_NOTIFY_EMAIL.indexOf('@example.com') !== -1) return;
  try {
    MailApp.sendEmail({
      to: ADMIN_NOTIFY_EMAIL,
      subject: 'إشعار ' + type + ' جديد من ' + center + ' - وحدة المقاصف',
      body: 'السلام عليكم،\n\n' +
        'وصل إشعار ' + type + ' جديد من مركز "' + center + '".\n' +
        (senderName ? ('اسم المسلّمة: ' + senderName + '\n') : '') +
        'المبلغ: ' + amount + ' ريال\n' +
        'اليوم: ' + now.day + '\n' +
        'التاريخ: ' + now.date + '\n' +
        'الوقت: ' + now.time + '\n\n' +
        'الرجاء الدخول للوحة إدارة وحدة المقاصف للاطلاع عليه وتوقيعه.\n' +
        (noticeImageUrl ? ('رابط صورة الإشعار: ' + noticeImageUrl + '\n') : '') +
        '\n— نظام وحدة المقاصف، جمعية فرقان لتحفيظ القرآن الكريم'
    });
  } catch (e) {
    // تجاهل خطأ الإرسال حتى لا يفشل حفظ الإشعار بسببه
  }
}

/* ------------------- الصعوبات والمقترحات ------------------- */

function recordDifficulty_(p) {
  const sh = sheet_('الصعوبات والمقترحات');
  const id = Utilities.getUuid();
  const now = nowParts_();
  appendRowByHeaders_(sh, {
    'معرف': id, 'اسم المركز': p.center || '', 'من': p.from || '', 'النوع': p.type || 'صعوبة',
    'النص': p.text || '', 'اليوم': now.day, 'التاريخ': now.date, 'الوقت': now.time
  });
  invalidateCache_('الصعوبات والمقترحات');
  notifyAdminNewDifficulty_(p.type, p.center, p.from, p.text, now);
  return { ok: true, id: id };
}

function notifyAdminNewDifficulty_(type, center, from, text, now) {
  center = centerDisplay_(center);
  from = centerDisplay_(from);
  if (!ADMIN_NOTIFY_EMAIL || ADMIN_NOTIFY_EMAIL.indexOf('@example.com') !== -1) return;
  try {
    MailApp.sendEmail({
      to: ADMIN_NOTIFY_EMAIL,
      subject: (type || 'صعوبة') + ' جديدة من ' + (center || '') + ' - وحدة المقاصف',
      body: 'السلام عليكم،\n\n' +
        'وصلت ' + (type || 'صعوبة') + ' جديدة من مركز "' + (center || '') + '".\n' +
        (from ? ('من: ' + from + '\n') : '') +
        '\nالنص:\n' + (text || '') + '\n\n' +
        'اليوم: ' + now.day + '\n' +
        'التاريخ: ' + now.date + '\n' +
        'الوقت: ' + now.time + '\n\n' +
        'الرجاء الدخول للوحة إدارة وحدة المقاصف للاطلاع.\n\n' +
        '— نظام وحدة المقاصف، جمعية فرقان لتحفيظ القرآن الكريم'
    });
  } catch (e) {
    // تجاهل خطأ الإرسال حتى لا يفشل الحفظ بسببه
  }
}

/* p.center: لو انمرّرت، ترجع صعوبات/مقترحات هذا المركز بس (يشوفها المركز نفسه).
   وإلا لو انمرّر p.from، ترجع اللي أرسلتها هذي الجهة بس (مسؤولة غير مربوطة بمركز).
   لو ما انمرّر ولا واحد منهم، ترجع الكل (لصفحة الإدارة). */
function getDifficulties_(p) {
  const rows = sheetToObjects_('الصعوبات والمقترحات');
  let filtered = rows;
  if (p && p.center) {
    filtered = rows.filter(function (r) { return String(r['اسم المركز']).trim() === String(p.center).trim(); });
  } else if (p && p.from) {
    filtered = rows.filter(function (r) { return String(r['من']).trim() === String(p.from).trim(); });
  }
  return { ok: true, items: filtered.reverse() };
}

function deleteDifficulty_(p) {
  const sh = sheet_('الصعوبات والمقترحات');
  sh.deleteRow(Number(p.row));
  invalidateCache_('الصعوبات والمقترحات');
  return { ok: true };
}

function getCenterNotices_(p) {
  let rows = getRowsForTerm_('الإشعارات', p.term, 'فصل الأرشفة');
  rows = rows.filter(function (r) { return String(r['اسم المركز']).trim() === String(p.center).trim(); });
  return { ok: true, notices: rows.reverse() };
}

/* تعديل خفيف على إشعار موجود: المبلغ و/أو اسم المسلّمة فقط
   (ما تُعدَّل الصورة/التوقيع/الحالة عشان تبقى السجلات الموقّعة موثوقة) */
function updateNotice_(p) {
  const sh = sheet_('الإشعارات');
  const row = Number(p.row);
  if (p.amount !== undefined && p.amount !== '') sh.getRange(row, colIndex_(sh, 'المبلغ')).setValue(Number(p.amount));
  if (p.senderName !== undefined) sh.getRange(row, colIndex_(sh, 'اسم المسلّمة')).setValue(p.senderName);
  invalidateCache_('الإشعارات');
  return { ok: true };
}

function deleteNotice_(p) {
  const sh = sheet_('الإشعارات');
  sh.deleteRow(Number(p.row));
  invalidateCache_('الإشعارات');
  return { ok: true };
}

function getPendingNotices_() {
  const rows = sheetToObjects_('الإشعارات').filter(function (r) {
    return r['الحالة'] === 'بانتظار الاطلاع';
  });
  return { ok: true, notices: rows.reverse() };
}

/* نسخة خفيفة من getPendingNotices_ - ترجع رقم العدد بس (بدون كل بيانات الإشعارات)
   تُستخدم لتحديث نقطة العداد على الشاشة الرئيسية بدون تحميل كل سجل الإشعارات كامل. */
function getPendingNoticesCount_() {
  const rows = sheetToObjects_('الإشعارات');
  let count = 0;
  for (let i = 0; i < rows.length; i++) {
    if (rows[i]['الحالة'] === 'بانتظار الاطلاع') count++;
  }
  return { ok: true, count: count };
}

/* نفس فكرة getPendingNoticesCount_ بس لمركز معيّن - تُستخدم لعداد الشاشة الرئيسية
   بمراكز/مسؤولات بدل ما نجيب كل تاريخ إشعارات المركز كامل بس عشان نعدّ منها. */
function getCenterPendingCount_(p) {
  const rows = sheetToObjects_('الإشعارات');
  const center = String(p.center || '').trim();
  let count = 0;
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i]['اسم المركز']).trim() === center && rows[i]['الحالة'] !== 'تم الاطلاع') count++;
  }
  return { ok: true, count: count };
}

// ترجع جميع إشعارات الاستلام والتسليم (بانتظار الاطلاع + تم الاطلاع) - تُستخدم بلوحة الإدارة
// افتراضياً فصل حالي بس (زي بقية شاشات الفصل الدراسي)؛ p.term = "all" أو اسم فصل سابق يوسّع النطاق
function getAllNotices_(p) {
  const rows = getRowsForTerm_('الإشعارات', p && p.term, 'فصل الأرشفة').slice().reverse();
  const pending = rows.filter(function (r) { return r['الحالة'] === 'بانتظار الاطلاع'; });
  const done = rows.filter(function (r) { return r['الحالة'] !== 'بانتظار الاطلاع'; });
  return { ok: true, pending: pending, done: done, notices: rows };
}

function adminSignNotice_(p) {
  const sh = sheet_('الإشعارات');
  const rows = sheetToObjects_('الإشعارات');
  const target = rows.find(function (r) { return r['معرف'] === p.id; });
  if (!target) return { ok: false, error: 'الإشعار غير موجود' };

  const now = nowParts_();

  // نحفظ الصورة النهائية الموقعة بس (فيها توقيع المركز + توقيع الإدارة سوا) - توفير وقت
  const signedImageUrl = saveImage_(p.signedNoticeImage,
    noticeFileName_('إشعار موقع', target['النوع'], target['اسم المركز'], target['تاريخ الإرسال'], p.id),
    ['الإشعارات', target['اسم المركز']]);

  const row = target._row;
  sh.getRange(row, colIndex_(sh, 'رابط توقيع الإدارة')).setValue('');            // لم يعد يُحفظ لوحده
  sh.getRange(row, colIndex_(sh, 'رابط صورة الإشعار الموقع')).setValue(signedImageUrl);
  sh.getRange(row, colIndex_(sh, 'يوم اطلاع الإدارة')).setValue(now.day);
  sh.getRange(row, colIndex_(sh, 'تاريخ اطلاع الإدارة')).setValue(now.date);
  sh.getRange(row, colIndex_(sh, 'وقت اطلاع الإدارة')).setValue(now.time);
  sh.getRange(row, colIndex_(sh, 'اسم المستلمة')).setValue(p.receiverName || '');
  sh.getRange(row, colIndex_(sh, 'الحالة')).setValue('تم الاطلاع');
  invalidateCache_('الإشعارات');

  return { ok: true };
}

/* -------- تعديل إشعار بعد توقيعه (الإدارة) --------
   يحدّث بيانات الإشعار بالشيت، ويحفظ صورة الإشعار الموقعة الجديدة (اللي تولّدها الصفحة من البيانات المعدّلة
   + توقيع المركز + توقيع الإدارة) ويستبدل رابطها. لو أرسلت الصفحة p.adminSignature نحفظه بـ Drive
   ونحط رابطه بعمود "رابط توقيع الإدارة" عشان التعديلات الجاية ما تحتاج تعيدين التوقيع. */
function setNoticeCell_(sh, row, header, value) {
  const c = colIndex_(sh, header);
  if (c > 0) sh.getRange(row, c).setValue(value);
}

function updateSignedNotice_(p) {
  const sh = sheet_('الإشعارات');
  const rows = sheetToObjects_('الإشعارات');
  const target = rows.find(function (r) { return r['معرف'] === p.id; });
  if (!target) return { ok: false, error: 'الإشعار غير موجود' };
  const amount = Number(p.amount);
  if (!(amount > 0)) return { ok: false, error: 'المبلغ غير صحيح' };

  // المركز الجديد لازم يكون موجود بشيت المراكز (نتحقق قبل ما نحفظ أي صورة)
  let newCenter = '';
  if (p.center) {
    newCenter = String(p.center).trim();
    const known = sheetToObjects_('المراكز', CACHE_SECONDS_LONG).map(function (r) { return String(r['اسم المركز']).trim(); });
    if (known.indexOf(newCenter) === -1) return { ok: false, error: 'المركز غير موجود بقائمة المراكز: ' + newCenter };
  }

  const row = target._row;
  const stamp = new Date().getTime();
  const effCenter = newCenter || target['اسم المركز'];
  const effType = p.type || target['النوع'];
  const effDate = p.date ? String(p.date).trim() : target['تاريخ الإرسال'];
  const signedImageUrl = p.signedNoticeImage
    ? saveImage_(p.signedNoticeImage,
        noticeFileName_('إشعار موقع', effType, effCenter, effDate, p.id) + ' (' + stamp + ')',
        ['الإشعارات', effCenter])
    : '';
  const adminSigUrl = p.adminSignature
    ? saveImage_(p.adminSignature, 'توقيع إدارة - ' + String(p.id).slice(0, 6) + ' (' + stamp + ')',
        ['الإشعارات', 'توقيعات الإدارة'])
    : '';

  if (p.type) setNoticeCell_(sh, row, 'النوع', p.type);
  if (newCenter) setNoticeCell_(sh, row, 'اسم المركز', newCenter);
  if (p.date) {
    setNoticeCell_(sh, row, 'تاريخ الإرسال', String(p.date).trim());
    setNoticeCell_(sh, row, 'يوم الإرسال', p.day || dayNameForDateStr_(p.date));
  } else if (p.day) {
    setNoticeCell_(sh, row, 'يوم الإرسال', p.day);
  }
  setNoticeCell_(sh, row, 'المبلغ', amount);
  if (p.senderName !== undefined) setNoticeCell_(sh, row, 'اسم المسلّمة', p.senderName);
  if (p.receiverName !== undefined) setNoticeCell_(sh, row, 'اسم المستلمة', p.receiverName);
  if (p.month !== undefined) setNoticeCell_(sh, row, 'الشهر', p.month);
  if (p.term !== undefined) setNoticeCell_(sh, row, 'الفصل الدراسي', p.term);
  if (p.year !== undefined) setNoticeCell_(sh, row, 'العام', p.year);
  if (p.reason !== undefined) setNoticeCell_(sh, row, 'بيان مخصص', p.reason);
  if (signedImageUrl) setNoticeCell_(sh, row, 'رابط صورة الإشعار الموقع', signedImageUrl);
  if (adminSigUrl) setNoticeCell_(sh, row, 'رابط توقيع الإدارة', adminSigUrl);
  invalidateCache_('الإشعارات');
  return { ok: true, signedImageUrl: signedImageUrl, adminSigUrl: adminSigUrl };
}

/* ترجع توقيع الإدارة المحفوظ سابقًا (كصورة base64) عشان الصفحة تعيد رسم الإشعار بدون ما تطلب توقيع جديد.
   القراءة من Drive بالسيرفر تتجنب مشكلة منع المتصفح لقراءة صور من موقع ثاني. */
function getNoticeAdminSignature_(p) {
  const rows = sheetToObjects_('الإشعارات');
  const target = rows.find(function (r) { return r['معرف'] === p.id; });
  if (!target) return { ok: false, error: 'الإشعار غير موجود' };
  const link = String(target['رابط توقيع الإدارة'] || '');
  const m = link.match(/[-\w]{25,}/);
  if (!m) return { ok: true, dataUrl: '' };
  try {
    const blob = DriveApp.getFileById(m[0]).getBlob();
    return { ok: true, dataUrl: 'data:' + (blob.getContentType() || 'image/png') + ';base64,' + Utilities.base64Encode(blob.getBytes()) };
  } catch (e) {
    return { ok: true, dataUrl: '' };
  }
}

/* تشغيل مرة وحدة يدوياً من المحرر: ترتّب صور الإشعارات القديمة (اللي انحفظت سابقاً مبعثرة بالمجلد الرئيسي)
   داخل مجلد "الإشعارات" > اسم المركز، وتعيد تسميتها باسم واضح. آمنة لو انشغلت أكثر من مرة
   (تتخطّى الملفات المرتّبة). لو وقفت بسبب الوقت، شغّليها مرة ثانية وتكمل. */
function organizeExistingNoticeFiles_() {
  const start = Date.now();
  const rows = sheetToObjects_('الإشعارات');
  const cols = [
    { header: 'رابط صورة الإشعار', prefix: 'إشعار', sig: false },
    { header: 'رابط صورة الإشعار الموقع', prefix: 'إشعار موقع', sig: false },
    { header: 'رابط توقيع الإدارة', prefix: 'توقيع إدارة', sig: true }
  ];
  let moved = 0, skipped = 0, failed = 0, stoppedEarly = false;
  for (let i = 0; i < rows.length && !stoppedEarly; i++) {
    const r = rows[i];
    for (let c = 0; c < cols.length; c++) {
      if (Date.now() - start > 270000) { stoppedEarly = true; break; }
      const link = String(r[cols[c].header] || '');
      const m = link.match(/[-\w]{25,}/);
      if (!m) continue;
      try {
        const target = cols[c].sig
          ? getOrCreateSubFolder_(['الإشعارات', 'توقيعات الإدارة'])
          : getOrCreateSubFolder_(['الإشعارات', r['اسم المركز']]);
        const file = DriveApp.getFileById(m[0]);
        const parents = file.getParents();
        if (parents.hasNext() && parents.next().getId() === target.getId()) { skipped++; continue; }
        file.moveTo(target);
        file.setName(cols[c].sig
          ? 'توقيع إدارة - ' + String(r['معرف'] || '').slice(0, 6)
          : noticeFileName_(cols[c].prefix, r['النوع'], r['اسم المركز'], r['تاريخ الإرسال'], r['معرف']) + '.png');
        moved++;
      } catch (e) {
        failed++;
        Logger.log('تعذر ترتيب ملف: ' + link + ' - ' + e);
      }
    }
  }
  Logger.log('تم نقل: ' + moved + ' | كانت مرتّبة: ' + skipped + ' | فشل: ' + failed +
    (stoppedEarly ? ' | توقفت بسبب الوقت، شغّليها مرة ثانية' : ' | اكتمل الترتيب ✅'));
}

/* ------------------- الإحصائيات (إيرادات المقاصف) ------------------- */

// دالة تشخيص: ترجع اسم/رابط ملف الإكسل اللي متصل فيه هذا الكود فعلياً، مع عدد صفوف كل شيت،
// تساعد لو صار لخبطة إن الموقع متصل بملف إكسل غير اللي المستخدمة تشوف فيه بياناتها
function debugInfo_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheetNames = ['المسؤولات', 'الحضور', 'التعهد', 'المهام', 'المراكز', 'المبيعات', 'المرتجعات', 'الفواتير', 'الإشعارات'];
  const sheetsInfo = sheetNames.map(function (name) {
    const sh = ss.getSheetByName(name);
    return { name: name, exists: !!sh, rows: sh ? Math.max(sh.getLastRow() - 1, 0) : 0 };
  });
  return {
    ok: true,
    spreadsheetName: ss.getName(),
    spreadsheetUrl: ss.getUrl(),
    sheets: sheetsInfo
  };
}

/* ------------------- بدء فصل دراسي جديد (ترحيل/تسمية البيانات) ------------------- */

/* تحط اسم الفصل الدراسي (p.termLabel، مثال: "الفصل الدراسي الأول ١٤٤٨هـ") على كل
   صف "حالي" (يعني عمود "الفصل الدراسي" فاضي فيه) بشيتات المبيعات/المرتجعات/الفواتير/الإشعارات.
   بهذا الشكل: أي صف قديم انحط له اسم فصل قبل كذا يضل كما هو (ما يتكتب فوقه)،
   وبس الصفوف "الحالية" (بدون تسمية) هي اللي تاخذ اسم الفصل المنتهي. بعدها أي بيانات
   جديدة تنسجل بدون فصل (يعني تعتبر فصل "حالي") لين يجي وقت الترحيل التالي. */
function archiveCurrentTerm_(p) {
  const termLabel = String(p.termLabel || '').trim();
  if (!termLabel) return { ok: false, error: 'اسم الفصل الدراسي مطلوب' };

  // لكل شيت اسم عمود الأرشفة الخاص فيه - "الإشعارات" لها عمود منفصل "فصل الأرشفة"
  // لأن عمود "الفصل الدراسي" فيها محجوز لغرض ثاني (فصل رسوم حفل تحفيظ الصغار)
  const sheetsToArchive = [
    { name: 'المبيعات', col: 'الفصل الدراسي' },
    { name: 'المرتجعات', col: 'الفصل الدراسي' },
    { name: 'الفواتير', col: 'الفصل الدراسي' },
    { name: 'الإشعارات', col: 'فصل الأرشفة' },
    { name: 'قائمة الدخل', col: 'الفصل الدراسي' }
  ];
  const counts = {};

  sheetsToArchive.forEach(function (entry) {
    const sh = sheet_(entry.name);
    if (!sh || sh.getLastRow() < 2) { counts[entry.name] = 0; return; }
    const col = colIndex_(sh, entry.col);
    if (col === -1) { counts[entry.name] = 0; return; }

    // ننقل الصفوف "الحالية" (عمود الأرشفة فاضي) فعلياً لشيت الأرشيف بعد ما نكتب
    // عليها اسم الفصل - فيرجع الشيت الحيّ صغيراً (بيانات الفصل الجديد بس) بدل
    // ما يتراكم فيه كل الفصول للأبد.
    const archiveSh = getOrCreateArchiveSheet_(entry.name);
    const n = archiveRowsMatching_(sh, archiveSh, col, function (v) { return String(v).trim() === ''; }, termLabel);
    counts[entry.name] = n;
    invalidateCache_(entry.name);
    invalidateCache_(ARCHIVE_PREFIX + entry.name);
  });

  return { ok: true, counts: counts };
}


/* ------------------- قائمة الدخل (الإيرادات والمصروفات - يدوي بالكامل) ------------------- */

function recordIncomeItem_(p) {
  const sh = sheet_('قائمة الدخل');
  const id = Utilities.getUuid();
  const now = nowParts_();
  let attachmentUrl = '';
  let attachmentName = '';
  if (p.fileData) {
    attachmentUrl = saveAttachmentFile_(p.fileData, p.fileName || ('مرفق-' + id), p.mimeType || '');
    attachmentName = p.fileName || '';
  }
  appendRowByHeaders_(sh, {
    'معرف': id, 'البند': p.category || '', 'البيان': p.description || '', 'المبلغ': Number(p.amount) || 0,
    'المبلغ كتابة': p.amountWords || '',
    'اليوم': now.day, 'التاريخ': now.date,
    'رابط المرفق': attachmentUrl, 'اسم المرفق': attachmentName
  });
  invalidateCache_('قائمة الدخل');
  return { ok: true, id: id };
}

/* تعديل بند موجود. لو انمرّر ملف مرفق جديد (p.fileData) يستبدل القديم (لو موجود)؛
   لو ما انمرّر، يبقى المرفق القديم كما هو (ما يُحذف بمجرد التعديل على المبلغ مثلاً). */
function updateIncomeItem_(p) {
  const sh = sheet_('قائمة الدخل');
  const row = Number(p.row);
  if (p.category !== undefined) sh.getRange(row, colIndex_(sh, 'البند')).setValue(p.category);
  if (p.description !== undefined) sh.getRange(row, colIndex_(sh, 'البيان')).setValue(p.description);
  if (p.amount !== undefined) sh.getRange(row, colIndex_(sh, 'المبلغ')).setValue(Number(p.amount));
  if (p.amountWords !== undefined) sh.getRange(row, colIndex_(sh, 'المبلغ كتابة')).setValue(p.amountWords);
  if (p.fileData) {
    const id = Utilities.getUuid();
    const url = saveAttachmentFile_(p.fileData, p.fileName || ('مرفق-' + id), p.mimeType || '');
    sh.getRange(row, colIndex_(sh, 'رابط المرفق')).setValue(url);
    sh.getRange(row, colIndex_(sh, 'اسم المرفق')).setValue(p.fileName || '');
  }
  invalidateCache_('قائمة الدخل');
  return { ok: true };
}

function getIncomeItems_(p) {
  let rows = getRowsForTerm_('قائمة الدخل', p && p.term, 'الفصل الدراسي');
  rows = rows.slice().reverse();
  let totalIncome = 0, totalExpenses = 0;
  rows.forEach(function (r) {
    const amt = Number(r['المبلغ']) || 0;
    if (r['البند'] === 'إيراد') totalIncome += amt;
    else if (r['البند'] === 'مصروفات') totalExpenses += amt;
  });
  return { ok: true, items: rows, totalIncome: totalIncome, totalExpenses: totalExpenses, netProfit: totalIncome - totalExpenses };
}

function deleteIncomeItem_(p) {
  const sh = sheet_('قائمة الدخل');
  sh.deleteRow(Number(p.row));
  invalidateCache_('قائمة الدخل');
  return { ok: true };
}

function getStats_() {
  const sales = sheetToObjects_('المبيعات');
  const byCenter = {};
  sales.forEach(function (r) {
    const c = String(r['اسم المركز'] || '').trim();
    if (!c) return;
    byCenter[c] = (byCenter[c] || 0) + (Number(r['المبلغ']) || 0);
  });
  let centersArr = Object.keys(byCenter).map(function (c) { return { center: c, total: byCenter[c] }; });
  centersArr.sort(function (a, b) { return b.total - a.total; });
  const grandTotal = centersArr.reduce(function (s, c) { return s + c.total; }, 0);
  return { ok: true, totalRevenue: grandTotal, centers: centersArr };
}


/* ------------------- التحليل الذكي: التزام المراكز بتسجيل المبيعات ------------------- *
 * يجاوب على: مين يسجّل أول بأول؟ مين متأخر؟ مين ما يسجّل؟ ومن متى؟
 *
 * فكرة القياس:
 *  - «سجّل اليوم» = يوجد سطر بشيت المبيعات لهذا التاريخ للمركز.
 *  - «أول بأول» = تاريخ التسجيل الفعلي (عمود «وقت التسجيل الفعلي» اللي يكتبه السيرفر) هو نفس تاريخ المبيعات.
 *    الصفوف القديمة (قبل إضافة هذا العمود) تُحسب «مسجّلة» لكن بدون حكم على التأخير.
 *  - أيام العمل تُحدَّد من الواجهة (الافتراضي الأحد-الخميس)، واليوم اللي ما سجّل فيه أي مركز
 *    نهائياً يُعتبر إجازة تلقائياً (لو عدد المراكز 3 أو أكثر) ولا يُحسب غياب على أحد.
 *  - كل المراكز تُحسب، ومنها مراكز «العرض فقط» (تسجّل لها مسؤولة المقصف). */

const ENTRY_STAMP_COL_ = 'وقت التسجيل الفعلي';

function entryStamp_() {
  const n = nowParts_();
  return n.date + ' ' + n.time;
}

function pad2_(n) { return (n < 10 ? '0' : '') + n; }

/* ترجع yyyy-MM-dd من أي نص يبدأ بتاريخ بهالصيغة (أو فاضي) */
function dateOnly_(v) {
  const m = String(v === undefined || v === null ? '' : v).trim().match(/^(\d{4})-(\d{2})-(\d{2})/);
  return m ? (m[1] + '-' + m[2] + '-' + m[3]) : '';
}

function ymdToUtc_(s) {
  const a = s.split('-');
  return Date.UTC(Number(a[0]), Number(a[1]) - 1, Number(a[2]));
}

function utcToYmd_(ms) {
  const d = new Date(ms);
  return d.getUTCFullYear() + '-' + pad2_(d.getUTCMonth() + 1) + '-' + pad2_(d.getUTCDate());
}

function daysBetween_(a, b) {
  return Math.round((ymdToUtc_(b) - ymdToUtc_(a)) / 86400000);
}

/* «HH:mm» -> عدد الدقائق من منتصف الليل (أو null) */
function timeToMin_(v) {
  const m = String(v === undefined || v === null ? '' : v).match(/(\d{1,2}):(\d{2})/);
  return m ? (Number(m[1]) * 60 + Number(m[2])) : null;
}

function minToTime_(min) {
  if (min === null || min === undefined) return '';
  return pad2_(Math.floor(min / 60)) + ':' + pad2_(min % 60);
}

function allRowsIncludingArchive_(name) {
  return sheetToObjects_(name).concat(sheetToObjects_(ARCHIVE_PREFIX + name));
}

function smartStatus_(m) {
  if (!m.expected) return 'nodata';
  if (m.recorded === 0 || m.trailingMissing >= 3) return 'stopped';
  if (m.compliance < 60) return 'follow';
  if (m.onTimeRate !== null && m.onTimeRate < 60) return 'late';
  if (m.compliance >= 90 && (m.onTimeRate === null || m.onTimeRate >= 80)) return 'excellent';
  return 'good';
}

function getSmartAnalysis_(p) {
  p = p || {};
  const today = nowParts_().date;

  // ---- الفترة ----
  let to = dateOnly_(p.to) || today;
  if (to > today) to = today;
  let from = dateOnly_(p.from) || utcToYmd_(ymdToUtc_(to) - 29 * 86400000);
  if (from > to) from = to;
  if (daysBetween_(from, to) > 365) from = utcToYmd_(ymdToUtc_(to) - 365 * 86400000);
  const spanLen = daysBetween_(from, to) + 1;
  const prevTo = utcToYmd_(ymdToUtc_(from) - 86400000);
  const prevFrom = utcToYmd_(ymdToUtc_(prevTo) - (spanLen - 1) * 86400000);

  // ---- أيام العمل (0=الأحد ... 6=السبت) ----
  let workdays = [0, 1, 2, 3, 4];
  if (p.workdays !== undefined && p.workdays !== null && p.workdays !== '') {
    const raw = Array.isArray(p.workdays) ? p.workdays : String(p.workdays).split(',');
    const parsed = raw.map(function (x) { return Number(x); }).filter(function (n) { return !isNaN(n) && n >= 0 && n <= 6; });
    if (parsed.length) workdays = parsed;
  }
  const autoOff = !(p.autoOff === false || p.autoOff === 'false');

  // ---- كل المراكز (تشمل مراكز «العرض فقط» لأن مسؤولة المقصف هي اللي تسجّل لها) ----
  const centers = [];
  sheetToObjects_('المراكز', CACHE_SECONDS_LONG).forEach(function (r) {
    const name = String(r['اسم المركز'] || '').trim();
    if (name && centers.indexOf(name) === -1) centers.push(name);
  });
  // مراكز مربوطة بمسؤولة بشيت المسؤولات وما هي مكتوبة بشيت المراكز
  sheetToObjects_('المسؤولات', CACHE_SECONDS_LONG).forEach(function (r) {
    const name = String(r['اسم المركز'] || '').trim();
    if (name && centers.indexOf(name) === -1) centers.push(name);
  });
  // أي اسم مركز له مبيعات مسجّلة بس ما هو بأي من الشيتين (مثلاً مكتوب باختلاف بسيط) ما نخليه يختفي
  const salesRows = allRowsIncludingArchive_('المبيعات');
  salesRows.forEach(function (r) {
    const name = String(r['اسم المركز'] || '').trim();
    if (name && centers.indexOf(name) === -1) centers.push(name);
  });

  const stats = {};
  centers.forEach(function (c) {
    stats[c] = { days: {}, last: '', prevTotal: 0, today: null };
  });

  // ---- المبيعات ----
  let rangeRows = 0, stampedRows = 0;
  salesRows.forEach(function (r) {
    const c = String(r['اسم المركز'] || '').trim();
    const st = stats[c];
    if (!st) return;
    const d = dateOnly_(r['التاريخ']);
    if (!d || d > today) return;
    const amt = Number(r['المبلغ']) || 0;
    const stamp = String(r[ENTRY_STAMP_COL_] || '');
    const stampDate = dateOnly_(stamp);
    const rawMin = timeToMin_(r['الوقت']);
    const stampMin = stampDate ? timeToMin_(stamp.slice(10)) : null;

    if (d > st.last) st.last = d;

    if (d === today) {
      if (!st.today) st.today = { total: 0, count: 0, min: null };
      st.today.total += amt;
      st.today.count++;
      const tm = (stampDate === today && stampMin !== null) ? stampMin : rawMin;
      if (tm !== null && (st.today.min === null || tm < st.today.min)) st.today.min = tm;
    }

    if (d >= prevFrom && d <= prevTo) { st.prevTotal += amt; return; }
    if (d < from || d > to) return;

    rangeRows++;
    let day = st.days[d];
    if (!day) day = st.days[d] = { total: 0, count: 0, lag: null, firstMin: null };
    day.total += amt;
    day.count++;
    if (stampDate) {
      stampedRows++;
      const lag = Math.max(0, daysBetween_(d, stampDate));
      if (day.lag === null || lag < day.lag) day.lag = lag;
      if (lag === 0 && stampMin !== null && (day.firstMin === null || stampMin < day.firstMin)) day.firstMin = stampMin;
    }
  });

  // ---- الفواتير والمرتجعات (أعداد فقط) ----
  const inv = {}, ret = {}, retValue = {};
  allRowsIncludingArchive_('الفواتير').forEach(function (r) {
    const c = String(r['اسم المركز'] || '').trim();
    const d = dateOnly_(r['التاريخ']);
    if (!stats[c] || !d || d < from || d > to) return;
    inv[c] = (inv[c] || 0) + 1;
  });
  allRowsIncludingArchive_('المرتجعات').forEach(function (r) {
    const c = String(r['اسم المركز'] || '').trim();
    const d = dateOnly_(r['التاريخ']);
    if (!stats[c] || !d || d < from || d > to) return;
    ret[c] = (ret[c] || 0) + 1;
    retValue[c] = (retValue[c] || 0) + (Number(r['القيمة']) || 0);
  });

  // ---- أيام العمل الفعلية للفترة (مع استثناء الإجازات التقديرية) ----
  const candidates = [];
  for (let t = ymdToUtc_(from); t <= ymdToUtc_(to); t += 86400000) {
    if (workdays.indexOf(new Date(t).getUTCDay()) !== -1) candidates.push(utcToYmd_(t));
  }
  const offDays = [];
  const effective = [];
  candidates.forEach(function (d) {
    if (d === today) { effective.push(d); return; }   // اليوم الحالي يُحكم عليه لكل مركز على حدة (ما انتهى بعد)
    if (autoOff && centers.length >= 3) {
      const anyone = centers.some(function (c) { return !!stats[c].days[d]; });
      if (!anyone) { offDays.push(d); return; }
    }
    effective.push(d);
  });

  // ---- مقاييس كل مركز ----
  const list = centers.map(function (c) {
    const st = stats[c];
    const eff = effective.filter(function (d) { return d !== today || !!st.days[d]; });
    const missing = [];
    let recorded = 0, onTime = 0, late = 0, lagSum = 0, known = 0, timeSum = 0, timeCnt = 0;
    eff.forEach(function (d) {
      const day = st.days[d];
      if (!day) { missing.push(d); return; }
      recorded++;
      if (day.lag !== null) {
        known++;
        if (day.lag === 0) {
          onTime++;
          if (day.firstMin !== null) { timeSum += day.firstMin; timeCnt++; }
        } else {
          late++;
          lagSum += day.lag;
        }
      }
    });

    let trailingMissing = 0;
    for (let i = eff.length - 1; i >= 0 && !st.days[eff[i]]; i--) trailingMissing++;
    let streak = 0;
    for (let j = eff.length - 1; j >= 0 && st.days[eff[j]]; j--) streak++;

    let total = 0, recordDaysAll = 0;
    Object.keys(st.days).forEach(function (d) { total += st.days[d].total; recordDaysAll++; });

    const expected = eff.length;
    const m = {
      center: c,
      expected: expected,
      recorded: recorded,
      missing: missing,
      missingCount: missing.length,
      compliance: expected ? Math.round(recorded / expected * 100) : null,
      onTime: onTime,
      late: late,
      knownTiming: known,
      onTimeRate: known ? Math.round(onTime / known * 100) : null,
      avgLagDays: late ? Math.round(lagSum / late * 10) / 10 : 0,
      avgTime: timeCnt ? minToTime_(Math.round(timeSum / timeCnt)) : '',
      lastRecord: st.last,
      trailingMissing: trailingMissing,
      streak: streak,
      total: total,
      avgPerDay: recordDaysAll ? Math.round(total / recordDaysAll * 100) / 100 : 0,
      prevTotal: st.prevTotal,
      changePct: st.prevTotal > 0 ? Math.round((total - st.prevTotal) / st.prevTotal * 100) : null,
      invoices: inv[c] || 0,
      returns: ret[c] || 0,
      returnsValue: retValue[c] || 0
    };
    m.status = smartStatus_(m);
    return m;
  });

  list.sort(function (a, b) {
    const ca = a.compliance === null ? -1 : a.compliance;
    const cb = b.compliance === null ? -1 : b.compliance;
    if (cb !== ca) return cb - ca;
    const oa = a.onTimeRate === null ? -1 : a.onTimeRate;
    const ob = b.onTimeRate === null ? -1 : b.onTimeRate;
    if (ob !== oa) return ob - oa;
    return a.center < b.center ? -1 : 1;
  });

  // ---- لقطة اليوم ----
  const todayDow = new Date(ymdToUtc_(today)).getUTCDay();
  const todaySnap = centers.map(function (c) {
    const t = stats[c].today;
    return { center: c, recorded: !!t, amount: t ? t.total : 0, time: t ? minToTime_(t.min) : '' };
  });

  // ---- نمط المبيعات حسب اليوم (متوسط مبلغ التسجيل الواحد لكل مركز باليوم) ----
  const dowAgg = {};
  centers.forEach(function (c) {
    Object.keys(stats[c].days).forEach(function (d) {
      const dow = new Date(ymdToUtc_(d)).getUTCDay();
      if (!dowAgg[dow]) dowAgg[dow] = { total: 0, n: 0 };
      dowAgg[dow].total += stats[c].days[d].total;
      dowAgg[dow].n++;
    });
  });
  const byDow = Object.keys(dowAgg).map(function (k) {
    const dow = Number(k);
    return { dow: dow, name: AR_DAYS_[dow], avg: Math.round(dowAgg[k].total / dowAgg[k].n * 100) / 100, n: dowAgg[k].n };
  }).sort(function (a, b) { return a.dow - b.dow; });

  // ---- ملخص عام ----
  let sumExpected = 0, sumRecorded = 0, totalSales = 0, prevSales = 0;
  list.forEach(function (m) {
    sumExpected += m.expected; sumRecorded += m.recorded;
    totalSales += m.total; prevSales += m.prevTotal;
  });

  return {
    ok: true,
    from: from, to: to, prevFrom: prevFrom, prevTo: prevTo, today: today,
    todayIsWorkday: workdays.indexOf(todayDow) !== -1,
    workdays: workdays, autoOff: autoOff,
    centers: list,
    todaySnap: todaySnap,
    byDow: byDow,
    offDays: offDays,
    effectiveDays: effective.length,
    summary: {
      activeCenters: centers.length,
      overallCompliance: sumExpected ? Math.round(sumRecorded / sumExpected * 100) : null,
      totalSales: totalSales,
      prevSales: prevSales,
      salesChangePct: prevSales > 0 ? Math.round((totalSales - prevSales) / prevSales * 100) : null
    },
    dataQuality: { rangeRows: rangeRows, stampedRows: stampedRows }
  };
}
